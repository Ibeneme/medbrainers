/**
 * POS FLOW TEST — drives the REAL POS page in jsdom against a stub HTTP API.
 * Needs dev dependencies:  jsdom  @testing-library/react  @testing-library/dom
 * Run:  node --import tsx --test src/app/dashboard/billing/__tests__/pos.flow.test.tsx
 */
import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import Module from "node:module";
import React from "react";
import { JSDOM } from "jsdom";

/* ───────── browser-ish globals (before React DOM loads) ───────── */
const dom = new JSDOM("<!doctype html><html><body></body></html>", { url: "http://localhost/dashboard/billing/pos" });
Object.assign(globalThis, { window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement, Node: dom.window.Node, MutationObserver: dom.window.MutationObserver, getComputedStyle: dom.window.getComputedStyle });
Object.defineProperty(globalThis, "navigator", { value: dom.window.navigator, configurable: true });
(dom.window as any).matchMedia = (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, onchange: null, dispatchEvent: () => false });
(globalThis as any).matchMedia = (dom.window as any).matchMedia;
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
(dom.window as any).scrollTo = () => {};

/* ───────── stub Next's router/link (they need the Next runtime) ───────── */
const pushed: string[] = [];
const nav = { useRouter: () => ({ push: (u: string) => pushed.push(u), replace: (u: string) => pushed.push(u), back() {}, prefetch() {} }), usePathname: () => "/dashboard/billing/pos", useSearchParams: () => new URLSearchParams(""), useParams: () => ({}) };
const Link = ({ href, children, ...rest }: any) => React.createElement("a", { href: typeof href === "string" ? href : String(href?.pathname ?? ""), ...rest }, children);
const origLoad = (Module as any)._load;
(Module as any)._load = function (request: string, ...args: any[]) {
  if (request === "next/navigation") return nav;
  if (request === "next/link") return { __esModule: true, default: Link };
  return origLoad.call(this, request, ...args);
};

/* ───────── stub API ───────── */
const PORT = 5177;
const FID = "64b0000000000000000000a1";
const ITEMS = [
  { _id: "i1", itemId: "CONS-00001", name: "General consultation", department: "consultation", unitPrice: 5000, isActive: true },
  { _id: "i2", itemId: "PHARM-00002", name: "Paracetamol 500mg", department: "pharmacy", unitPrice: 1250.5, isActive: true },
];
const seen = { quotes: [] as any[], invoices: [] as any[] };
const server = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    const json = (data: unknown, status = 200) => (res.writeHead(status, { "content-type": "application/json", "access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "*" }), res.end(JSON.stringify({ success: true, data })));
    const url = new URL(req.url!, "http://x");
    if (req.method === "OPTIONS") return json({});
    const p = url.pathname.replace(`/companies/${FID}/billing`, "");
    if (req.method === "GET" && p === "/settings") return json({ acceptCashPayments: true, currency: "NGN", allowManualDiscount: false, maxManualDiscountPercent: 20, invoicePrefix: "INV" });
    if (req.method === "GET" && p === "/catalog") {
      const q = (url.searchParams.get("search") || "").toLowerCase();
      return json({ items: ITEMS.filter((i) => i.name.toLowerCase().includes(q)), total: 2, page: 1, limit: 50 });
    }
    if (req.method === "GET" && url.pathname.endsWith("/patients")) return json([]);
    const b = body ? JSON.parse(body) : {};
    if (req.method === "POST" && p === "/cart/quote") {
      seen.quotes.push(b);
      const lines = b.lines.map((l: any) => { const it = ITEMS.find((i) => i.itemId === l.itemId)!; const gross = it.unitPrice * l.quantity; return { itemId: it.itemId, itemRef: it._id, name: it.name, department: it.department, unitPrice: it.unitPrice, quantity: l.quantity, gross, discount: 0, net: gross, appliedRuleIds: [] }; });
      const subtotal = lines.reduce((a: number, l: any) => a + l.gross, 0);
      const coupon = (b.couponCodes || []).includes("WELCOME10");
      const off = coupon ? Math.round(subtotal * 0.1 * 100) / 100 : 0;
      return setTimeout(() => json({ currency: "NGN", lines, appliedDiscounts: coupon ? [{ kind: "rule", name: "Welcome 10%", code: "WELCOME10", type: "percentage", amount: off }] : [], subtotal, discountTotal: off, total: subtotal - off, unusedCodes: (b.couponCodes || []).filter((c: string) => c !== "WELCOME10") }), 60);
    }
    if (req.method === "POST" && p === "/invoices") { seen.invoices.push(b); return json({ _id: "inv1", status: b.issue ? "issued" : "draft", invoiceNumber: b.issue ? "INV-000001" : undefined, lines: [], appliedDiscounts: [], couponCodes: [], currency: "NGN", subtotal: 0, discountTotal: 0, total: 0, amountPaid: 0, balance: 0, overpaid: false, createdAt: "", updatedAt: "" }); }
    json({}, 404);
  });
});

test("POS: pick items → server prices the cart → coupon → issue (and never trusts or sends a client price)", async () => {
  await new Promise<void>((r) => server.listen(PORT, r));
  process.env.NEXT_PUBLIC_API_URL = `http://127.0.0.1:${PORT}`;
  try {
    const { render, screen, waitFor, fireEvent, cleanup } = await import("@testing-library/react");
    const { Provider } = await import("react-redux");
    const { configureStore } = await import("@reduxjs/toolkit");
    const rootReducer = (await import("../../../../api/slices")).default;
    const { ThemeProvider } = await import("../../../../contexts/theme-context");
    const { ToastProvider } = await import("../../../../contexts/toast-context");
    const Pos = (await import("../pos/page")).default;

    const store = configureStore({
      reducer: rootReducer,
      middleware: (g) => g({ serializableCheck: false, immutableCheck: false }),
      preloadedState: {
        facilities: { activeFacilityId: FID, activeFacility: { id: FID, name: "Grace Hospital" }, members: [], membersLoading: false },
        access: { byFacility: { [FID]: { companyId: FID, role: "cashier", roles: [], roleKeys: ["cashier"], isOwner: false, isSuperAdmin: false, permissions: ["billing.view", "billing.write", "billing.collect", "patients.view"], directPermissions: [], deniedPermissions: [], modules: {} } }, status: "ready", error: null },
      } as any,
    });
    render(
      <Provider store={store}><ThemeProvider><ToastProvider><Pos /></ToastProvider></ThemeProvider></Provider>,
    );

    // 1. the picker loads priced items from the API
    const consult = await screen.findByText("General consultation", {}, { timeout: 4000 });
    assert.ok(await screen.findByText("Paracetamol 500mg"));
    assert.ok(screen.getByText("The cart is empty"));

    // 2. add the same item twice → one cart line, quantity 2
    fireEvent.click(consult.closest("button")!);
    await screen.findByText(/Cart \(1\)/);
    fireEvent.click(consult.closest("button")!);
    const qty = (await screen.findByLabelText("Quantity of General consultation")) as HTMLInputElement;
    await waitFor(() => assert.equal(qty.value, "2"));

    // 3. the Issue button is DISABLED while the price on screen is stale, then enabled once the server answers
    const issue = () => screen.getByRole("button", { name: /Issue invoice/ }) as HTMLButtonElement;
    assert.equal(issue().disabled, true, "must not issue against a stale/unknown price");
    await waitFor(() => assert.ok(screen.getAllByText("₦10,000").length > 0), { timeout: 4000 }); // total comes from the SERVER's quote
    await waitFor(() => assert.equal(issue().disabled, false));

    // 4. changing quantity makes the quote stale again immediately
    fireEvent.click(screen.getByRole("button", { name: "More" }));
    assert.equal(issue().disabled, true, "stale again the instant the cart changes");
    await waitFor(() => assert.ok(screen.getAllByText("₦15,000").length > 0), { timeout: 4000 });
    await waitFor(() => assert.equal(issue().disabled, false));

    // 5. a coupon is sent to the server and its discount shown from the server's answer
    fireEvent.change(screen.getByPlaceholderText("e.g. WELCOME10"), { target: { value: "welcome10" } });
    fireEvent.click(screen.getByRole("button", { name: /Add$/ }));
    await waitFor(() => assert.ok(screen.getByText("Welcome 10%")), { timeout: 4000 });
    await waitFor(() => assert.ok(screen.getAllByText("₦13,500").length > 0)); // 15,000 − 10%

    // 6. every quote request carried ids+quantities only — never a price
    assert.ok(seen.quotes.length >= 3);
    for (const q of seen.quotes) {
      assert.deepEqual(Object.keys(q.lines[0]).sort(), ["itemId", "quantity"]);
      assert.ok(!JSON.stringify(q).includes("unitPrice"));
    }
    const last = seen.quotes.at(-1);
    assert.deepEqual(last.lines, [{ itemId: "CONS-00001", quantity: 3 }]);
    assert.deepEqual(last.couponCodes, ["WELCOME10"]);

    // 7. issue → server called with issue:true, then we go to the invoice page to take payment
    await waitFor(() => assert.equal(issue().disabled, false));
    fireEvent.click(issue());
    await waitFor(() => assert.equal(seen.invoices.length, 1), { timeout: 4000 });
    assert.equal(seen.invoices[0].issue, true);
    assert.deepEqual(seen.invoices[0].lines, [{ itemId: "CONS-00001", quantity: 3 }]);
    await waitFor(() => assert.deepEqual(pushed, ["/dashboard/billing/invoices/inv1"]));

    // 8. the cashier has no billing.discount permission → no manual-discount control at all
    assert.equal(screen.queryByText(/Give a manual discount/), null);
    cleanup();
  } finally {
    server.close();
  }
});
