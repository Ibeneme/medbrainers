"use client";

import { PRIMARY_COLOR } from "@/constants/colors";
import React, { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { T } from "@/i18n/provider";
import { productName } from "@/constants/site";

gsap.registerPlugin(ScrollTrigger);

interface EMRFeatureCard {
  number: string;
  title: string;
  description: string;
  actionText: string;
}

const emrFeatures: EMRFeatureCard[] = [
  {
    number: "01",
    title: "Hospital Management System",
    description:
      "Comprehensive administration & coordination. Unify cross-departmental operations, billing, and resource planning on a single reliable platform.",
    actionText: "Explore hospital suite",
  },
  {
    number: "02",
    title: "Clinic Information System",
    description:
      "Scheduling, queue & practitioner tools. Optimize outpatient flow, reduce patient wait times, and empower clinicians with rapid scheduling interfaces.",
    actionText: "View clinic workflows",
  },
  {
    number: "03",
    title: "Electronic Medical Record (EMR)",
    description:
      "Clinical notes, vitals & patient history. Maintain comprehensive SOAP notes, vital tracking, and instant secure access to full longitudinal patient records.",
    actionText: "Discover EMR modules",
  },
  {
    number: "04",
    title: "Industry Clinic System",
    description:
      "Workplace health & occupational services. Tailored enterprise health modules for managing employee physicals, periodic assessments, and workplace injury logs.",
    actionText: "Explore occupational tools",
  },
  {
    number: "05",
    title: "Dental Clinic Management",
    description:
      "Specialized charts & graphical odontograms. Complete visual dental charting, treatment planning, and procedure tracking built specifically for dental practices.",
    actionText: "Check dental features",
  },
  {
    number: "06",
    title: "Pharmacy Management System",
    description:
      "Dispensing, stock alerts & prescriptions. Track inventory in real-time, automate stock warnings, and seamlessly process electronic prescriptions from clinicians.",
    actionText: "View pharmacy tools",
  },
  {
    number: "07",
    title: "Hospital Records Management",
    description:
      "Secure digital archiving & fast retrieval. High-speed document indexing, encrypted archiving, and compliance-grade data protection for legacy and current files.",
    actionText: "Learn about records",
  },
  {
    number: "08",
    title: "Operating Theatre Management",
    description:
      "Surgical checklists & real-time tracking. Manage surgical schedules, track theatre utilization, and enforce safety checklists with live operational updates.",
    actionText: "Explore theatre suite",
  },
];

export default function EnterpriseSupportSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: headerRef.current,
            start: "top 85%",
          },
        }
      );

      gsap.fromTo(
        gridRef.current?.children || [],
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.08,
          ease: "power3.out",
          scrollTrigger: {
            trigger: gridRef.current,
            start: "top 85%",
          },
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative w-full pt-[1rem] pb-[6rem] bg-black text-white overflow-hidden border-b border-white/5"
    >
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 flex flex-col items-start">
        {/* Header Section */}
        <div ref={headerRef} className="text-left max-w-4xl mb-[5rem]">
          <h2 className="text-3xl md:text-5xl lg:text-6xl font-extrabold text-[#f3f4f6] tracking-tight leading-[1.1]">
            <T>
              Comprehensive solutions built for every department in modern
              healthcare
            </T>
            <span style={{ color: PRIMARY_COLOR }}>.</span>
          </h2>

          <p className="mt-6 text-lg md:text-xl text-neutral-300 font-light max-w-3xl leading-relaxed">
            <T>
              From patient admission and electronic clinical records to
              specialized dental charting, theatre scheduling, and pharmacy
              dispensing, {productName} connects your entire care ecosystem into
              a single unified platform.
            </T>
          </p>
        </div>

        {/* Feature Grid Section */}
        <div
          ref={gridRef}
          className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-[1.5rem]"
        >
          {emrFeatures.map((card, index) => (
            <div
              key={index}
              className="p-[2rem] rounded-2xl bg-neutral-950 border border-white/10 hover:border-white/20 transition-all duration-300 flex flex-col justify-between group shadow-none"
            >
              <div>
                <div
                  className="w-[2.5rem] h-[2.5rem] rounded-lg bg-white/5 border border-white/10 flex items-center justify-center mb-[1.5rem] font-mono text-sm"
                  style={{ color: PRIMARY_COLOR }}
                >
                  {card.number}
                </div>
                <h3 className="text-xl font-bold text-white tracking-tight mb-[0.75rem]">
                  <T>{card.title}</T>
                </h3>
                <p className="text-neutral-400 text-sm font-light leading-relaxed">
                  <T>{card.description}</T>
                </p>
              </div>
              <div className="mt-[2rem] pt-[1rem] border-t border-white/5 flex items-center justify-between text-xs text-neutral-400 group-hover:text-white transition-colors">
                <span>
                  <T>{card.actionText}</T>
                </span>
                <span className="font-mono" style={{ color: PRIMARY_COLOR }}>
                  &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
