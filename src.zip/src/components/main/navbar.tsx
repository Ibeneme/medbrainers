"use client";

import { PRIMARY_COLOR } from "@/constants/colors";
import React, { useState, useEffect, useRef } from "react";
import Link from "@/i18n/link";
import LanguageSwitcher from "@/i18n/language-switcher";
import { Flag } from "@/i18n/flags";
import { localeMeta } from "@/i18n/config";
import Image from "next/image";
import { T, useT, useLocale } from "@/i18n/provider";
import MedbrainersLoader from "../atoms/loaders/Medbrainersloader";
import { productName } from "@/constants/site";

type Variant = "primary" | "deep" | "surface";

const solutionsItems: {
  title: string;
  description: string;
  href: string;
  variant: Variant;
}[] = [
  {
    title: "Hospital Management System",
    description: "Comprehensive administration & coordination",
    href: "/solutions#hospital-management",
    variant: "primary",
  },
  {
    title: "Clinic Information System",
    description: "Scheduling, queue & practitioner tools",
    href: "/solutions#clinic-information",
    variant: "surface",
  },
  {
    title: "Electronic Medical Record (EMR)",
    description: "Clinical notes, vitals & patient history",
    href: "/solutions#emr",
    variant: "deep",
  },
  {
    title: "Industry Clinic System",
    description: "Workplace health & occupational services",
    href: "/solutions#industry-clinic",
    variant: "surface",
  },
  {
    title: "Dental Clinic Management",
    description: "Specialized charts & graphical odontograms",
    href: "/solutions#dental-clinic",
    variant: "surface",
  },
  {
    title: "Pharmacy Management System",
    description: "Dispensing, stock alerts & prescriptions",
    href: "/solutions#pharmacy-management",
    variant: "surface",
  },
  {
    title: "Hospital Records Management",
    description: "Secure digital archiving & fast retrieval",
    href: "/solutions#hospital-records",
    variant: "surface",
  },
  {
    title: "Operating Theatre Management",
    description: "Surgical checklists & real-time tracking",
    href: "/solutions#operating-theatre",
    variant: "surface",
  },
];

const Arrow = ({ className = "" }: { className?: string }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    viewBox="0 0 24 24"
    aria-hidden="true"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M5 12h14M12 5l7 7-7 7"
    />
  </svg>
);

const Chevron = ({ className = "" }: { className?: string }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    viewBox="0 0 24 24"
    aria-hidden="true"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
  </svg>
);

interface LandingPageNavbarProps {
  showOnlyOneButton?: boolean;
  primaryButton?: "get-started";
  mobileShowOnlyOneButton?: boolean;
  mobilePrimaryButton?: "get-started";
}

export default function LandingPageNavbar({
  showOnlyOneButton = true,
  primaryButton = "get-started",
  mobileShowOnlyOneButton = true,
  mobilePrimaryButton = "get-started",
}: LandingPageNavbarProps) {
  const t = useT();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobileSolutionsOpen, setIsMobileSolutionsOpen] = useState(false);

  // State to track hover for displaying the loader per card
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const langDropdownRef = useRef<HTMLDivElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const currentLocale = useLocale();

  useEffect(() => {
    setIsLangOpen(false);
    setIsMobileMenuOpen(false);
  }, [currentLocale]);

  const openSolutions = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setIsSolutionsOpen(true);
  };
  const closeSolutionsSoon = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => {
      setIsSolutionsOpen(false);
      setHoveredIndex(null);
    }, 120);
  };

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 100);

    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;

      if (dropdownRef.current && !dropdownRef.current.contains(target)) {
        setIsSolutionsOpen(false);
        setHoveredIndex(null);
      }

      if (
        langDropdownRef.current &&
        !langDropdownRef.current.contains(target)
      ) {
        setIsLangOpen(false);
      }

      if (
        mobileMenuRef.current &&
        !mobileMenuRef.current.contains(target) &&
        !(target as HTMLElement).closest("[data-mobile-toggle]")
      ) {
        setIsMobileMenuOpen(false);
        setIsMobileSolutionsOpen(false);
      }
    };

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsSolutionsOpen(false);
        setHoveredIndex(null);
        setIsLangOpen(false);
        setIsMobileMenuOpen(false);
        setIsMobileSolutionsOpen(false);
      }
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKey);

    return () => {
      if (closeTimer.current) clearTimeout(closeTimer.current);
      window.removeEventListener("scroll", handleScroll);
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKey);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = isMobileMenuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  const renderActionButtons = () => {
    const base =
      "inline-flex items-center justify-center px-5 py-2.5 rounded-full text-sm font-semibold text-white transition-opacity hover:opacity-90 shadow-lg";

    return (
      <Link
        href="/get-started"
        style={{ backgroundColor: PRIMARY_COLOR }}
        className={base}
      >
        <T>Get Started</T>
      </Link>
    );
  };

  return (
    <header
      className={`fixed left-0 right-0 z-50 mx-auto font-lufga transition-all duration-300 ease-in-out ${
        isScrolled
          ? "top-4 w-[calc(100%-2rem)] max-w-5xl rounded-full border border-white/10 bg-[#0a0a0a] px-6 py-3 sm:top-6"
          : "top-0 w-full max-w-7xl border border-transparent bg-transparent px-5 py-4 sm:px-8 md:py-5"
      }`}
    >
      <div className="flex w-full items-center justify-between">
        <div className="flex items-center gap-8">
          <Link
            href="/"
            className="flex items-center gap-2.5 text-xl font-bold tracking-tight text-white"
          >
            {isScrolled ? (
              <div className="relative h-7 w-7 overflow-hidden">
                <Image
                  src="/medbrainers-logo.svg"
                  alt={productName}
                  fill
                  className="object-cover"
                />
              </div>
            ) : (
              <MedbrainersLoader
                showText={false}
                size={32}
                fontUrl=""
                className=""
                tileColor={PRIMARY_COLOR}
              />
            )}

            <span>
              <T>{productName}</T>
              <span style={{ color: PRIMARY_COLOR }}>.</span>
            </span>
          </Link>

          <nav
            aria-label={t("Main")}
            className="hidden items-center gap-6 text-sm font-medium text-white md:flex"
          >
            <div
              ref={dropdownRef}
              onMouseEnter={openSolutions}
              onMouseLeave={closeSolutionsSoon}
            >
              <button
                type="button"
                onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                aria-expanded={isSolutionsOpen}
                aria-haspopup="true"
                className="flex cursor-pointer items-center gap-1.5 py-1 text-white/80 transition-colors hover:text-white"
              >
                <span>
                  <T>Solutions</T>
                </span>
                <Chevron
                  className={`h-3.5 w-3.5 transition-transform duration-200 ${
                    isSolutionsOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {isSolutionsOpen && (
                <div className="absolute left-1/2 top-full z-50 w-[min(880px,calc(100vw-2rem))] -translate-x-1/2 pt-3">
                  <div className="grid grid-cols-3 gap-3 rounded-3xl border border-white/10 bg-[#0d0d0f] p-3">
                    {solutionsItems.map((item, i) => {
                      const isTall = i === 0;
                      let bgStyle: React.CSSProperties | undefined = undefined;
                      let cardClass =
                        "group relative flex flex-col justify-between overflow-hidden rounded-2xl p-5 transition-colors border";
                      let titleClass = "text-white";
                      let descClass = "text-white/70";
                      let arrowClass = "text-white/70";

                      if (item.variant === "primary") {
                        bgStyle = { backgroundColor: PRIMARY_COLOR };
                        cardClass += " border-transparent";
                      } else if (item.variant === "deep") {
                        bgStyle = { backgroundColor: "#ffffff" };
                        cardClass += " border-white/20";
                        titleClass = "text-black";
                        descClass = "text-black/70";
                        arrowClass = "text-black/70";
                      } else {
                        cardClass +=
                          " bg-[#151518] hover:bg-[#1c1c20] border-white/[0.07] hover:border-white/15";
                      }

                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onMouseEnter={() => setHoveredIndex(i)}
                          onMouseLeave={() => setHoveredIndex(null)}
                          onClick={() => {
                            setIsSolutionsOpen(false);
                            setHoveredIndex(null);
                          }}
                          style={bgStyle}
                          className={`${cardClass} ${
                            isTall
                              ? "row-span-2 min-h-[300px]"
                              : "min-h-[140px]"
                          }`}
                        >
                          <div className="w-full">
                            <div className="flex items-start justify-between gap-2">
                              <span
                                className={`block text-[15px] font-semibold leading-snug ${titleClass}`}
                              >
                                <T>{item.title}</T>
                              </span>

                              {hoveredIndex === i ? (
                                <div className="shrink-0">
                                  <MedbrainersLoader
                                    showText={false}
                                    size={18}
                                    fontUrl=""
                                    className=""
                                     tileColor={PRIMARY_COLOR}
                                  />
                                </div>
                              ) : (
                                <Arrow
                                  className={`mt-0.5 h-4 w-4 shrink-0 transition-transform duration-200 group-hover:translate-x-1 ${arrowClass}`}
                                />
                              )}
                            </div>
                            <span
                              className={`mt-2 block text-sm leading-snug ${descClass}`}
                            >
                              <T>{item.description}</T>
                            </span>
                          </div>

                          {isTall && (
                            <span
                              className={`mt-8 inline-flex items-center gap-2 text-sm font-medium ${titleClass}`}
                            >
                              <T>Explore the platform</T>
                              <Arrow className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                            </span>
                          )}
                        </Link>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <Link
              href="/pricing"
              className="text-white/80 transition-colors hover:text-white"
            >
              <T>Pricing</T>
            </Link>

            <Link
              href="/blog"
              className="text-white/80 transition-colors hover:text-white"
            >
              <T>Blog</T>
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative hidden md:block" ref={langDropdownRef}>
            <button
              type="button"
              onClick={() => setIsLangOpen((prev) => !prev)}
              aria-expanded={isLangOpen}
              className="flex items-center gap-2.5 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-white/95 hover:bg-white/15 transition-colors cursor-pointer shadow-sm"
            >
              <Flag locale={currentLocale} />
              <span>{localeMeta[currentLocale].name}</span>
              <Chevron
                className={`h-3.5 w-3.5 transition-transform duration-200 ${
                  isLangOpen ? "rotate-180" : ""
                }`}
              />
            </button>

            {isLangOpen && (
              <div className="absolute right-0 top-full mt-2 w-48 rounded-2xl border border-white/10 bg-[#0d0d0f] p-2 shadow-2xl z-50 flex flex-col gap-1">
                <div className="px-3.5 py-1 text-[11px] font-semibold text-white/45 uppercase tracking-wider">
                  {t("Select Language")}
                </div>
                <div className="flex flex-col gap-1">
                  <LanguageSwitcher
                    onSelect={() => {
                      setIsLangOpen(false);
                      setIsMobileMenuOpen(false);
                    }}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="hidden sm:block">{renderActionButtons()}</div>

          <button
            type="button"
            data-mobile-toggle
            onClick={() => {
              setIsMobileMenuOpen((prev) => !prev);
              setIsMobileSolutionsOpen(false);
            }}
            className="relative z-[60] cursor-pointer rounded-lg p-2.5 text-white transition-colors hover:bg-white/10 md:hidden"
            aria-label={t("Toggle Menu")}
            aria-expanded={isMobileMenuOpen}
          >
            <svg
              className="h-6 w-6"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d={
                  isMobileMenuOpen
                    ? "M6 18L18 6M6 6l12 12"
                    : "M4 6h16M4 12h16M4 18h16"
                }
              />
            </svg>
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div
          ref={mobileMenuRef}
          className="absolute left-0 right-0 top-full z-[55] mt-3 flex max-h-[80vh] flex-col overflow-y-auto rounded-2xl border border-white/10 bg-[#0a0a0a] p-5 md:hidden"
        >
          <button
            type="button"
            onClick={() => setIsMobileSolutionsOpen(!isMobileSolutionsOpen)}
            aria-expanded={isMobileSolutionsOpen}
            className="flex w-full items-center justify-between py-3 text-left text-base font-medium text-white"
          >
            <span>
              <T>Solutions</T>
            </span>
            <Chevron
              className={`h-4 w-4 transition-transform duration-200 ${
                isMobileSolutionsOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          {isMobileSolutionsOpen && (
            <div className="mb-2 ml-1 flex flex-col gap-1 border-l border-white/10 pl-3">
              {solutionsItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => {
                    setIsMobileSolutionsOpen(false);
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center justify-between gap-2 py-2 text-sm text-gray-300 transition-colors hover:text-white"
                >
                  <span className="flex items-center gap-2">
                    <T>{item.title}</T>
                  </span>
                  <Arrow className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                </Link>
              ))}
            </div>
          )}

          <Link
            href="/pricing"
            onClick={() => setIsMobileMenuOpen(false)}
            className="border-t border-white/10 py-3 text-base font-medium text-white"
          >
            <T>Pricing</T>
          </Link>

          <Link
            href="/blog"
            onClick={() => setIsMobileMenuOpen(false)}
            className="border-t border-white/10 py-3 text-base font-medium text-white"
          >
            <T>Blog</T>
          </Link>

          <div className="mt-1 flex flex-col gap-2 border-t border-white/10 pt-4">
            <span className="text-xs font-semibold text-white/45 uppercase tracking-wider px-1">
              {t("Language")}
            </span>
            <div className="flex flex-col gap-1">
              <LanguageSwitcher
                onSelect={() => {
                  setIsLangOpen(false);
                  setIsMobileMenuOpen(false);
                }}
              />
            </div>
          </div>
          <div className="mt-3 border-t border-white/10 pt-3">
            {renderActionButtons()}
          </div>
        </div>
      )}
    </header>
  );
}
