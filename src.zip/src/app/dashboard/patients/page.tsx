"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Building2,
  ChevronRight,
  Loader2,
  Plus,
  Search,
  UserCheck,
  UserMinus,
  Users,
} from "lucide-react";
import { useAppDispatch, useAppSelector } from "@/api/hooks";
import { fetchMyFacilities, fetchPatients } from "@/api/slices";
import { useTheme } from "@/contexts/theme-context";
import { PRIMARY_COLOR } from "@/constants/colors";
import { CustomDropdown } from "@/components/ui/items";
import { UserAvatar } from "@/components/ui";
import DarkBlurOverlayLoader from "@/components/atoms/loaders/DarkBlurOverlayLoader";

type UI = {
  isDark: boolean;
  page: string;
  card: string;
  inner: string;
  text: string;
  border: string;
};

const STATUS_STYLE: Record<string, { color: string; bg: string }> = {
  active: { color: "#059669", bg: "rgba(16,185,129,0.14)" },
  inactive: { color: "#6b7280", bg: "rgba(107,114,128,0.16)" },
  discharged: { color: "#d97706", bg: "rgba(245,158,11,0.16)" },
};

function SummaryCard({
  icon: Icon,
  label,
  value,
  color,
  ui,
}: {
  icon: any;
  label: string;
  value: number;
  color: string;
  ui: UI;
}) {
  return (
    <div
      className="flex items-center gap-4 rounded-[28px] p-5"
      style={{ backgroundColor: ui.card }}
    >
      <span
        className="flex h-12 w-12 items-center justify-center rounded-2xl"
        style={{ backgroundColor: ui.inner, color }}
      >
        <Icon size={20} />
      </span>
      <div>
        <p className="text-xs opacity-60">{label}</p>
        <p className="text-3xl font-medium leading-tight tracking-tight">
          {value}
        </p>
      </div>
    </div>
  );
}

export default function PatientDirectoryPage() {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { theme, colors } = useTheme();
  const isDark = theme === "dark";
  const border = isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)";

  const ui: UI = {
    isDark,
    page: isDark ? "rgba(255,255,255,0.03)" : "#eef2f7",
    card: isDark ? colors.shadeBg : "#ffffff",
    inner: isDark ? colors.shadeBgSecond : "#f3f5f9",
    text: colors.text,
    border,
  };

  const { activeFacilityId, activeFacility } = useAppSelector(
    (s) => s.facilities
  );
  const { list, listLoading } = useAppSelector((s) => s.patients);
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    dispatch(fetchMyFacilities());
  }, [dispatch]);

  useEffect(() => {
    if (!activeFacilityId) return;
    const t = setTimeout(() => {
      dispatch(
        fetchPatients({
          facilityId: activeFacilityId,
          search: search || undefined,
        })
      );
    }, 250);
    return () => clearTimeout(t);
  }, [dispatch, activeFacilityId, search]);

  const filteredList = list.filter((p) => {
    if (genderFilter !== "all" && p.gender !== genderFilter) return false;
    if (statusFilter !== "all" && p.status !== statusFilter) return false;
    return true;
  });

  if (!activeFacilityId) {
    return (
      <div
        className="max-w-lg mx-auto px-4 py-16 text-center"
        style={{ color: colors.text }}
      >
        <Building2 className="mx-auto opacity-30 mb-3" size={32} />
        <p className="font-bold">Select a facility first</p>
      </div>
    );
  }

  const total = list.length;
  const activeCount = list.filter((p) => p.status === "active").length;
  const dischargedCount = list.filter((p) => p.status === "discharged").length;

  return (
    <div className="mx-auto max-w-6xl px-3 sm:px-6 py-4 sm:py-6">
      <div
        className="relative rounded-[32px] p-4 sm:p-6 space-y-5"
        style={{ backgroundColor: ui.page, color: ui.text }}
      >
        {listLoading && <DarkBlurOverlayLoader text="Loading patients..." />}

        {/* Title row */}
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="mb-1 text-xs opacity-60">{activeFacility?.name}</p>
            <h1 className="text-3xl sm:text-4xl font-normal tracking-tight">
              Patient directory
            </h1>
          </div>
          <Link
            href="/dashboard/patients/register"
            className="inline-flex items-center gap-1.5 rounded-full px-5 py-2.5 text-xs font-semibold text-white transition hover:opacity-90"
            style={{ backgroundColor: PRIMARY_COLOR }}
          >
            <Plus size={14} /> Register patient
          </Link>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <SummaryCard
            icon={Users}
            label="Patients in list"
            value={total}
            color={PRIMARY_COLOR}
            ui={ui}
          />
          <SummaryCard
            icon={UserCheck}
            label="Active"
            value={activeCount}
            color="#10b981"
            ui={ui}
          />
          <SummaryCard
            icon={UserMinus}
            label="Discharged"
            value={dischargedCount}
            color="#f59e0b"
            ui={ui}
          />
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div
            className="flex items-center gap-2.5 rounded-full px-4 py-3"
            style={{ backgroundColor: ui.card }}
          >
            <Search size={15} className="opacity-50 shrink-0" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, MRN, phone…"
              className="w-full bg-transparent text-sm outline-none"
              style={{ color: ui.text }}
            />
          </div>
          <CustomDropdown
            value={genderFilter}
            options={[
              { label: "All Genders", value: "all" },
              { label: "Male", value: "male" },
              { label: "Female", value: "female" },
              { label: "Other", value: "other" },
            ]}
            onChange={(val) => setGenderFilter(val)}
            placeholder="Filter by gender..."
            isDark={isDark}
            colors={colors}
            border={border}
          />
          <CustomDropdown
            value={statusFilter}
            options={[
              { label: "All Statuses", value: "all" },
              { label: "Active", value: "active" },
              { label: "Inactive", value: "inactive" },
              { label: "Discharged", value: "discharged" },
            ]}
            onChange={(val) => setStatusFilter(val)}
            placeholder="Filter by status..."
            isDark={isDark}
            colors={colors}
            border={border}
          />
        </div>

        {/* Table */}
        <div
          className="rounded-[28px] p-3 sm:p-4"
          style={{ backgroundColor: ui.card }}
        >
          {listLoading && list.length === 0 ? (
            <div className="flex items-center justify-center gap-2 p-12 text-xs opacity-60">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading…
            </div>
          ) : filteredList.length === 0 ? (
            <div className="p-12 text-center text-sm opacity-60">
              No patients found.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="text-xs opacity-50">
                    <th className="px-3 pb-3 font-medium">Patient</th>
                    <th className="px-3 pb-3 font-medium">MRN</th>
                    <th className="px-3 pb-3 font-medium hidden sm:table-cell">
                      Gender
                    </th>
                    <th className="px-3 pb-3 font-medium hidden md:table-cell">
                      Contact
                    </th>
                    <th className="px-3 pb-3 font-medium">Status</th>
                    <th className="px-3 pb-3 w-8" />
                  </tr>
                </thead>
                <tbody>
                  {filteredList.map((p) => {
                    const st =
                      STATUS_STYLE[p.status as string] || STATUS_STYLE.inactive;
                    return (
                      <tr
                        key={p._id}
                        onClick={() =>
                          router.push(`/dashboard/patients/${p._id}`)
                        }
                        className="cursor-pointer border-t transition hover:bg-black/[0.03] dark:hover:bg-white/[0.04]"
                        style={{ borderColor: ui.border }}
                      >
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-3">
                            <UserAvatar user={p} size="sm" />
                            <Link
                              href={`/dashboard/patients/${p._id}`}
                              onClick={(e) => e.stopPropagation()}
                              className="font-semibold hover:underline"
                            >
                              {p.firstName} {p.lastName}
                            </Link>
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <span
                            className="rounded-full px-2.5 py-1 font-mono text-[11px]"
                            style={{ backgroundColor: ui.inner }}
                          >
                            {p.mrn}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-xs capitalize hidden sm:table-cell opacity-70">
                          {p.gender || "—"}
                        </td>
                        <td className="px-3 py-3 text-xs opacity-60 hidden md:table-cell">
                          {[p.countryCode, p.phone].filter(Boolean).join(" ") ||
                            p.email ||
                            "—"}
                        </td>
                        <td className="px-3 py-3">
                          <span
                            className="rounded-full px-2.5 py-1 text-[11px] font-semibold capitalize"
                            style={{ color: st.color, backgroundColor: st.bg }}
                          >
                            {p.status || "—"}
                          </span>
                        </td>
                        <td className="px-3 py-3 opacity-40">
                          <ChevronRight size={16} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
