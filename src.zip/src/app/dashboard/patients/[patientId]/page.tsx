"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  Activity,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  BarChart3,
  Building2,
  ChevronRight,
  Edit3,
  Heart,
  LineChart as LineChartIcon,
  Minus,
  Plus,
  ShieldAlert,
  ShieldCheck,
  Thermometer,
  Trash2,
  Users,
  Wind,
  X,
} from "lucide-react";
import { useAppDispatch, useAppSelector } from "@/api/hooks";
import {
  fetchMyFacilities,
  fetchPatients,
  fetchPatient,
  fetchPatientFamily,
  addPatientAllergy,
  updatePatientAllergy,
  removePatientAllergy,
  addPatientVital,
  updatePatientVital,
  removePatientVital,
  addPatientHistory,
  addPatientFamily,
  linkFamily,
  removeFromFamilyGroup,
} from "@/api/slices";
import { useTheme } from "@/contexts/theme-context";
import { PRIMARY_COLOR } from "@/constants/colors";
import {
  CustomDropdown,
  CustomSearchableMultiSelect,
  personLabel,
  UserAvatar,
} from "@/components/ui";
import DarkBlurOverlayLoader from "@/components/atoms/loaders/DarkBlurOverlayLoader";

/* -------------------------------------------------------------------------- */
/*  Design tokens                                                             */
/* -------------------------------------------------------------------------- */

type UI = {
  isDark: boolean;
  page: string; // soft page frame
  card: string; // white cards
  inner: string; // tiles / chips inside cards
  text: string;
  border: string; // only used for inputs, table rules and chart grid
};

const inputCls =
  "w-full rounded-2xl border px-4 py-3 text-sm outline-none focus:outline-none focus:ring-2 focus:ring-black/10 dark:focus:ring-white/20";

type Metric = {
  key: string;
  label: string;
  unit: string;
  icon: any;
  color: string;
  domain: [number, number];
  normal: [number, number];
  decimals: number;
};

const METRICS: Metric[] = [
  {
    key: "temperatureC",
    label: "Temperature",
    unit: "°C",
    icon: Thermometer,
    color: "#f97316",
    domain: [34, 41],
    normal: [36.1, 37.5],
    decimals: 1,
  },
  {
    key: "spo2",
    label: "Blood Oxygen (SpO2)",
    unit: "%",
    icon: Wind,
    color: "#3b82f6",
    domain: [80, 100],
    normal: [95, 100],
    decimals: 0,
  },
  {
    key: "pulseBpm",
    label: "Pulse Rate",
    unit: " bpm",
    icon: Heart,
    color: "#ec4899",
    domain: [40, 140],
    normal: [60, 100],
    decimals: 0,
  },
  {
    key: "bpSystolic",
    label: "Systolic Pressure",
    unit: " mmHg",
    icon: Activity,
    color: "#10b981",
    domain: [70, 180],
    normal: [90, 120],
    decimals: 0,
  },
  {
    key: "bpDiastolic",
    label: "Diastolic Pressure",
    unit: " mmHg",
    icon: Activity,
    color: "#8b5cf6",
    domain: [40, 120],
    normal: [60, 80],
    decimals: 0,
  },
];

const SEVERITY_STYLE: Record<string, { color: string; label: string }> = {
  mild: { color: "#10b981", label: "Mild" },
  moderate: { color: "#f59e0b", label: "Moderate" },
  severe: { color: "#f97316", label: "Severe" },
  life_threatening: { color: "#ef4444", label: "Life-threatening" },
};

const fmt = (v: any, unit: string) => (v != null ? `${v}${unit}` : "—");

const rangeStatus = (m: Metric, v: number | null) => {
  if (v == null) return null;
  if (v < m.normal[0]) return { text: "Low", tone: "warn" as const };
  if (v > m.normal[1]) return { text: "High", tone: "warn" as const };
  return { text: "Good", tone: "ok" as const };
};

/* -------------------------------------------------------------------------- */
/*  Modal + confirmation modal                                                */
/* -------------------------------------------------------------------------- */

function Modal({
  open,
  title,
  onClose,
  children,
  ui,
  z = 50,
  maxWidth = "max-w-lg",
  escape = true,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  ui: UI;
  z?: number;
  maxWidth?: string;
  escape?: boolean;
}) {
  useEffect(() => {
    if (!open || !escape) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, escape, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200"
      style={{ zIndex: z }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`relative w-full ${maxWidth} rounded-[28px] p-6 space-y-5 max-h-[90vh] overflow-y-auto outline-none`}
        style={{ backgroundColor: ui.card, color: ui.text }}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium tracking-tight">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-full opacity-70 hover:opacity-100 transition outline-none focus:outline-none"
            style={{ backgroundColor: ui.inner }}
          >
            <X size={15} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

type ConfirmState = {
  title: string;
  message: string;
  confirmLabel: string;
  tone: "danger" | "primary";
  onConfirm: () => Promise<void>;
} | null;

function ConfirmModal({
  state,
  busy,
  onCancel,
  onConfirm,
  ui,
}: {
  state: ConfirmState;
  busy: boolean;
  onCancel: () => void;
  onConfirm: () => void;
  ui: UI;
}) {
  const danger = state?.tone === "danger";
  const accent = danger ? "#ef4444" : PRIMARY_COLOR;
  return (
    <Modal
      open={!!state}
      title={state?.title || ""}
      onClose={() => !busy && onCancel()}
      ui={ui}
      z={60}
      maxWidth="max-w-sm"
    >
      <div className="flex items-start gap-3">
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: `${accent}1f`, color: accent }}
        >
          {danger ? <AlertTriangle size={18} /> : <ShieldCheck size={18} />}
        </div>
        <p className="text-sm leading-relaxed opacity-75">{state?.message}</p>
      </div>
      <div className="flex justify-end gap-2">
        <button
          type="button"
          disabled={busy}
          onClick={onCancel}
          className="rounded-full px-5 py-2.5 text-xs font-semibold disabled:opacity-50 outline-none focus:outline-none"
          style={{ backgroundColor: ui.inner }}
        >
          Cancel
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={onConfirm}
          className="rounded-full px-5 py-2.5 text-xs font-semibold text-white disabled:opacity-50 outline-none focus:outline-none"
          style={{ backgroundColor: accent }}
        >
          {busy ? "Working..." : state?.confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

/* -------------------------------------------------------------------------- */
/*  Overview widgets: stat card, smooth sparkline, tick bars                  */
/* -------------------------------------------------------------------------- */

function StatCard({
  icon: Icon,
  label,
  value,
  unit,
  color,
  status,
  ui,
  children,
}: {
  icon: any;
  label: string;
  value: string;
  unit?: string;
  color: string;
  status?: { text: string; tone: "ok" | "warn" } | null;
  ui: UI;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-[28px] p-5 space-y-4"
      style={{ backgroundColor: ui.card }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span
            className="flex h-11 w-11 items-center justify-center rounded-2xl"
            style={{ backgroundColor: ui.inner, color }}
          >
            <Icon size={18} />
          </span>
          <div>
            <p className="text-xs opacity-60">{label}</p>
            <p className="text-2xl font-medium leading-tight tracking-tight">
              {value}
              {unit && (
                <span className="ml-1 text-sm font-normal opacity-50">
                  {unit}
                </span>
              )}
            </p>
          </div>
        </div>
        {status && (
          <span
            className="rounded-md px-2 py-0.5 text-[10px] font-bold uppercase"
            style={{
              color: status.tone === "ok" ? "#059669" : "#d97706",
              backgroundColor:
                status.tone === "ok"
                  ? "rgba(16,185,129,0.16)"
                  : "rgba(245,158,11,0.18)",
            }}
          >
            {status.text}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}

function Sparkline({
  id,
  values,
  color,
  unit,
}: {
  id: string;
  values: (number | null)[];
  color: string;
  unit: string;
}) {
  const pts = values.filter((v): v is number => v != null);
  const W = 300;
  const H = 92;
  const pad = 8;
  if (pts.length === 0) {
    return (
      <div className="flex h-[92px] items-center justify-center text-[11px] opacity-40">
        No readings yet
      </div>
    );
  }
  const lo = Math.min(...pts);
  const hi = Math.max(...pts);
  const span = hi - lo || Math.max(Math.abs(hi) * 0.1, 1);
  const min = lo - span * 0.3;
  const max = hi + span * 0.3;
  const y = (v: number) => 24 + (1 - (v - min) / (max - min)) * (H - 24 - 8);
  const n = pts.length;
  const coords: [number, number][] =
    n === 1
      ? [
          [pad, y(pts[0])],
          [W - pad, y(pts[0])],
        ]
      : pts.map((v, i) => [pad + (i * (W - 2 * pad)) / (n - 1), y(v)]);

  let d = `M${coords[0][0]} ${coords[0][1]}`;
  for (let i = 1; i < coords.length; i++) {
    const [x0, y0] = coords[i - 1];
    const [x1, y1] = coords[i];
    const mx = (x0 + x1) / 2;
    d += ` C${mx} ${y0} ${mx} ${y1} ${x1} ${y1}`;
  }
  const first = coords[0];
  const last = coords[coords.length - 1];
  const area = `${d} L${last[0]} ${H} L${first[0]} ${H} Z`;
  const gid = `spark-${id}`;
  const lastVal = pts[pts.length - 1];

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" aria-hidden>
        <defs>
          <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.22" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        <path d={area} fill={`url(#${gid})`} />
        <path
          d={d}
          fill="none"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle
          cx={last[0]}
          cy={last[1]}
          r="4.5"
          fill="#fff"
          stroke={color}
          strokeWidth="2"
        />
      </svg>
      <span
        className="absolute rounded-full px-2 py-0.5 text-[10px] font-semibold text-white whitespace-nowrap"
        style={{
          backgroundColor: color,
          left: `${(last[0] / W) * 100}%`,
          top: `${(last[1] / H) * 100}%`,
          transform: "translate(-100%, -150%)",
        }}
      >
        {lastVal}
        {unit.trim()}
      </span>
    </div>
  );
}

function TickBars({
  values,
  color,
  ui,
}: {
  values: (number | null)[];
  color: string;
  ui: UI;
}) {
  const N = 18;
  const vals = values.filter((v): v is number => v != null).slice(-N);
  if (vals.length === 0) {
    return (
      <div className="flex h-[92px] items-center justify-center text-[11px] opacity-40">
        No readings yet
      </div>
    );
  }
  const lo = Math.min(...vals);
  const hi = Math.max(...vals);
  const slots: (number | null)[] = [
    ...Array.from({ length: N - vals.length }, () => null),
    ...vals,
  ];
  return (
    <div className="flex h-[92px] items-end justify-between gap-1.5">
      {slots.map((v, i) => {
        const isLast = i === slots.length - 1;
        const h = v == null ? 22 : 34 + ((v - lo) / (hi - lo || 1)) * 66;
        if (isLast) {
          return (
            <div
              key={i}
              className="flex h-full items-end justify-center rounded-full px-1.5"
              style={{ backgroundColor: `${color}22` }}
            >
              <div
                className="w-[3px] rounded-full"
                style={{ height: `${h}%`, backgroundColor: color }}
              />
            </div>
          );
        }
        return (
          <div
            key={i}
            className="w-0 border-l-2 border-dashed"
            style={{
              height: `${h}%`,
              borderColor: v == null ? ui.border : `${color}66`,
              opacity: v == null ? 0.6 : 1,
            }}
          />
        );
      })}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Chart tab widgets                                                         */
/* -------------------------------------------------------------------------- */

type Series = { name: string; color: string; data: (number | null)[] };

function TrendChart({
  id,
  labels,
  fullLabels,
  series,
  domain,
  bands,
  mode,
  alerts,
  unit,
  grid,
}: {
  id: string;
  labels: string[];
  fullLabels: string[];
  series: Series[];
  domain: [number, number];
  bands?: [number, number][];
  mode: "line" | "bar";
  alerts: boolean[];
  unit: string;
  grid: string;
}) {
  const W = 440;
  const H = 190;
  const pL = 40;
  const pR = 12;
  const pT = 14;
  const pB = 28;
  const iw = W - pL - pR;
  const ih = H - pT - pB;
  const [min, max] = domain;
  const n = labels.length;
  const clamp = (v: number) => Math.min(Math.max(v, min), max);
  const y = (v: number) => pT + ih * (1 - (clamp(v) - min) / (max - min));
  const slot = iw / Math.max(n, 1);
  const xLine = (i: number) =>
    n === 1 ? pL + iw / 2 : pL + (i * iw) / (n - 1);
  const xBar = (i: number) => pL + slot * (i + 0.5);
  const ticks = [0, 1, 2, 3, 4].map((t) => min + ((max - min) * t) / 4);
  const step = Math.ceil(n / 6);
  const gid = `grad-${id}`;

  const pathOf = (data: (number | null)[]) => {
    const pts: [number, number][] = [];
    let d = "";
    let prev: [number, number] | null = null;
    data.forEach((v, i) => {
      if (v == null) {
        prev = null;
        return;
      }
      const p: [number, number] = [xLine(i), y(v)];
      if (!prev) d += `M${p[0].toFixed(1)} ${p[1].toFixed(1)} `;
      else {
        const mx = (prev[0] + p[0]) / 2;
        d += `C${mx.toFixed(1)} ${prev[1].toFixed(1)} ${mx.toFixed(
          1
        )} ${p[1].toFixed(1)} ${p[0].toFixed(1)} ${p[1].toFixed(1)} `;
      }
      prev = p;
      pts.push(p);
    });
    return d;
  };

  const single = series.length === 1;
  const barW = Math.min(26, (slot * 0.72) / series.length);

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full h-auto"
      role="img"
      aria-label="Vitals chart"
    >
      {single && (
        <defs>
          <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={series[0].color} stopOpacity="0.22" />
            <stop offset="100%" stopColor={series[0].color} stopOpacity="0" />
          </linearGradient>
        </defs>
      )}

      {(bands || []).map(([lo, hi], bi) => (
        <g key={bi}>
          <rect
            x={pL}
            y={y(hi)}
            width={iw}
            height={Math.max(y(lo) - y(hi), 1)}
            rx="6"
            fill="#10b981"
            opacity="0.1"
          />
          {bi === 0 && (
            <text
              x={W - pR - 6}
              y={y(hi) + 11}
              textAnchor="end"
              fontSize="8"
              fill="#10b981"
            >
              Normal
            </text>
          )}
        </g>
      ))}

      {ticks.map((t, i) => (
        <g key={i}>
          <line
            x1={pL}
            x2={W - pR}
            y1={y(t)}
            y2={y(t)}
            stroke={grid}
            strokeDasharray="3 5"
          />
          <text
            x={pL - 6}
            y={y(t) + 3}
            textAnchor="end"
            fontSize="9"
            fill="currentColor"
            opacity="0.5"
          >
            {Number.isInteger(t) ? t : t.toFixed(1)}
          </text>
        </g>
      ))}

      {labels.map((l, i) =>
        i % step === 0 || i === n - 1 ? (
          <text
            key={i}
            x={mode === "bar" ? xBar(i) : xLine(i)}
            y={H - 8}
            textAnchor="middle"
            fontSize="9"
            fill="currentColor"
            opacity="0.5"
          >
            {l}
          </text>
        ) : null
      )}

      {mode === "line" &&
        series.map((s, si) => {
          const allPresent = s.data.every((v) => v != null) && n > 1;
          return (
            <g key={si}>
              {single && allPresent && (
                <path
                  d={`${pathOf(s.data)} L${xLine(n - 1)} ${y(min)} L${xLine(
                    0
                  )} ${y(min)} Z`}
                  fill={`url(#${gid})`}
                />
              )}
              <path
                d={pathOf(s.data)}
                fill="none"
                stroke={s.color}
                strokeWidth="2.25"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {s.data.map((v, i) =>
                v == null ? null : (
                  <circle
                    key={i}
                    cx={xLine(i)}
                    cy={y(v)}
                    r={alerts[i] ? 4.5 : 3.5}
                    fill={alerts[i] ? "#ef4444" : "#fff"}
                    stroke={alerts[i] ? "#ef4444" : s.color}
                    strokeWidth="2"
                  >
                    <title>{`${fullLabels[i]}\n${s.name}: ${v}${unit}`}</title>
                  </circle>
                )
              )}
            </g>
          );
        })}

      {mode === "bar" &&
        series.map((s, si) =>
          s.data.map((v, i) => {
            if (v == null) return null;
            const x =
              xBar(i) -
              (series.length * barW) / 2 +
              si * barW +
              (single ? 0 : 1);
            const top = y(v);
            const base = y(min);
            const w = Math.max(barW - (single ? 0 : 2), 2);
            return (
              <g key={`${si}-${i}`}>
                <rect
                  x={x}
                  y={top}
                  width={w}
                  height={Math.max(base - top, 2)}
                  rx={Math.min(8, w / 2)}
                  fill={single && alerts[i] ? "#ef4444" : s.color}
                  opacity={single && alerts[i] ? 1 : 0.9}
                >
                  <title>{`${fullLabels[i]}\n${s.name}: ${v}${unit}`}</title>
                </rect>
                {n <= 8 && (
                  <text
                    x={x + w / 2}
                    y={top - 4}
                    textAnchor="middle"
                    fontSize="8.5"
                    fill="currentColor"
                    opacity="0.65"
                  >
                    {v}
                  </text>
                )}
              </g>
            );
          })
        )}
    </svg>
  );
}

function RangeGauge({
  metric,
  latest,
  previous,
  ui,
  large = false,
}: {
  metric: Metric;
  latest: number | null;
  previous: number | null;
  ui: UI;
  large?: boolean;
}) {
  const [min, max] = metric.domain;
  const [lo, hi] = metric.normal;
  const pct = (v: number) =>
    `${Math.min(Math.max((v - min) / (max - min), 0), 1) * 100}%`;
  return (
    <div
      className={`relative rounded-full ${large ? "h-4" : "h-3"}`}
      style={{ backgroundColor: ui.inner }}
    >
      <div
        className="absolute inset-y-0 rounded-full"
        style={{
          left: pct(lo),
          width: `${((hi - lo) / (max - min)) * 100}%`,
          background: "linear-gradient(90deg,#fde68a,#34d399)",
        }}
      />
      {previous != null && (
        <span
          className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2"
          style={{
            left: pct(previous),
            borderColor: metric.color,
            backgroundColor: ui.card,
            opacity: 0.8,
          }}
          title={`Previous: ${previous}${metric.unit}`}
        />
      )}
      {latest != null && (
        <span
          className="absolute top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px]"
          style={{
            left: pct(latest),
            backgroundColor: metric.color,
            borderColor: ui.card,
          }}
          title={`Latest: ${latest}${metric.unit}`}
        />
      )}
    </div>
  );
}

function MetricSnapshot({
  metric,
  latest,
  previous,
  ui,
}: {
  metric: Metric;
  latest: number | null;
  previous: number | null;
  ui: UI;
}) {
  const [lo, hi] = metric.normal;
  const delta =
    latest != null && previous != null
      ? Number((latest - previous).toFixed(metric.decimals))
      : null;
  return (
    <StatCard
      icon={metric.icon}
      label={metric.label}
      value={latest != null ? String(latest) : "—"}
      unit={metric.unit.trim()}
      color={metric.color}
      status={rangeStatus(metric, latest)}
      ui={ui}
    >
      <div className="space-y-2.5">
        {delta != null && (
          <span
            className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold"
            style={{ backgroundColor: ui.inner }}
          >
            {delta > 0 ? (
              <ArrowUp size={12} />
            ) : delta < 0 ? (
              <ArrowDown size={12} />
            ) : (
              <Minus size={12} />
            )}
            {Math.abs(delta)} vs previous
          </span>
        )}
        <RangeGauge
          metric={metric}
          latest={latest}
          previous={previous}
          ui={ui}
        />
        <div className="flex justify-between text-[10px] opacity-50">
          <span>
            {metric.domain[0]}
            {metric.unit.trim()}
          </span>
          <span>
            Normal {lo}–{hi}
            {metric.unit.trim()}
          </span>
          <span>
            {metric.domain[1]}
            {metric.unit.trim()}
          </span>
        </div>
      </div>
    </StatCard>
  );
}

/* -------------------------------------------------------------------------- */
/*  Small cards                                                               */
/* -------------------------------------------------------------------------- */

function AllergyCard({
  a,
  canManage,
  onEdit,
  onDelete,
  bg,
}: {
  a: any;
  canManage: boolean;
  onEdit: () => void;
  onDelete: () => void;
  bg: string;
}) {
  const sev =
    SEVERITY_STYLE[a.severity || "moderate"] || SEVERITY_STYLE.moderate;
  return (
    <div
      className="rounded-2xl p-4 flex items-start justify-between gap-3"
      style={{ backgroundColor: bg }}
    >
      <div className="flex min-w-0 flex-1 items-start gap-3">
        <span
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: `${sev.color}1f`, color: sev.color }}
        >
          <ShieldAlert size={18} />
        </span>
        <div className="min-w-0 space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-semibold">{a.substance}</span>
            <span
              className="rounded-full px-2 py-0.5 text-[10px] font-bold"
              style={{ color: sev.color, backgroundColor: `${sev.color}1f` }}
            >
              {sev.label}
            </span>
          </div>
          {a.reaction && (
            <p className="text-xs opacity-65">Reaction: {a.reaction}</p>
          )}
        </div>
      </div>
      {canManage && (
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onEdit}
            className="flex h-8 w-8 items-center justify-center rounded-full opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition outline-none focus:outline-none"
            title="Edit allergy"
            aria-label="Edit allergy"
          >
            <Edit3 size={15} />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="flex h-8 w-8 items-center justify-center rounded-full opacity-60 hover:opacity-100 hover:bg-red-500/10 hover:text-red-500 transition outline-none focus:outline-none"
            title="Remove allergy"
            aria-label="Remove allergy"
          >
            <Trash2 size={15} />
          </button>
        </div>
      )}
    </div>
  );
}

function VitalTile({
  label,
  value,
  icon: Icon,
  color,
  ui,
}: {
  label: string;
  value: string;
  icon: any;
  color: string;
  ui: UI;
}) {
  return (
    <div className="rounded-2xl p-3.5" style={{ backgroundColor: ui.inner }}>
      <span
        className="flex items-center gap-1.5 text-[11px] font-medium"
        style={{ color }}
      >
        <Icon size={13} /> {label}
      </span>
      <span className="mt-1.5 block text-base font-medium tracking-tight">
        {value}
      </span>
    </div>
  );
}

function PillButton({
  onClick,
  children,
  disabled,
  type = "button",
}: {
  onClick?: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className="inline-flex items-center gap-1.5 rounded-full px-5 py-2.5 text-xs font-semibold text-white transition hover:opacity-90 disabled:opacity-50 outline-none focus:outline-none"
      style={{ backgroundColor: PRIMARY_COLOR }}
    >
      {children}
    </button>
  );
}

/* -------------------------------------------------------------------------- */
/*  Page                                                                      */
/* -------------------------------------------------------------------------- */

export default function PatientDetailPage() {
  const params = useParams();
  const patientId = String(params.patientId || "");
  const dispatch = useAppDispatch();
  const { theme, colors } = useTheme();
  const isDark = theme === "dark";
  const border = isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)";

  const ui: UI = {
    isDark,
    page: isDark ? "rgba(255,255,255,0.03)" : "#eef2f7",
    card: isDark ? colors.shadeBg : "#ffffff",
    inner: isDark ? colors.shadeBgSecond : "#f3f5f9",
    text: colors.text,
    border,
  };

  const { activeFacilityId, activeFacility } = useAppSelector(
    (s) => s.facilities
  );
  const { list, current, familyOf, detailLoading, saving } = useAppSelector(
    (s) => s.patients
  );

  const currentUser = useAppSelector((s: any) => s.auth?.user);

  // Set this to `true` if every staff member should manage allergies.
  const canManageAllergies = useMemo(() => {
    const role = currentUser?.role?.toLowerCase() || "";
    return (
      role.includes("admin") ||
      role.includes("doctor") ||
      role.includes("physician") ||
      role.includes("provider") ||
      role.includes("nurse") ||
      role.includes("clinician")
    );
  }, [currentUser]);

  const [tab, setTab] = useState<
    "overview" | "allergies" | "vitals" | "family" | "chart"
  >("overview");
  const [chartView, setChartView] = useState<"line" | "bar">("line");
  const [chartRange, setChartRange] = useState<6 | 12 | 24>(12);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // Confirmation modal
  const [confirm, setConfirm] = useState<ConfirmState>(null);
  const [confirming, setConfirming] = useState(false);

  // Modals state
  const [allergyModalOpen, setAllergyModalOpen] = useState(false);
  const [editingAllergyId, setEditingAllergyId] = useState<string | null>(null);
  const [vitalModalOpen, setVitalModalOpen] = useState(false);
  const [editingVitalId, setEditingVitalId] = useState<string | null>(null);
  const [familyModalOpen, setFamilyModalOpen] = useState(false);
  const [chartModalOpen, setChartModalOpen] = useState(false);

  // Allergy form
  const [substance, setSubstance] = useState("");
  const [severity, setSeverity] = useState("moderate");
  const [reaction, setReaction] = useState("");

  // Vital form
  const [temperature, setTemperature] = useState("");
  const [bloodOxygenSaturation, setBloodOxygenSaturation] = useState("");
  const [pulseRate, setPulseRate] = useState("");
  const [bloodPressureSystolic, setBloodPressureSystolic] = useState("");
  const [bloodPressureDiastolic, setBloodPressureDiastolic] = useState("");

  // Chart
  const [noteTitle, setNoteTitle] = useState("");
  const [noteDetail, setNoteDetail] = useState("");

  // Family contact
  const [famName, setFamName] = useState("");
  const [famRel, setFamRel] = useState("");
  const [famPhone, setFamPhone] = useState("");
  const [famLinkIds, setFamLinkIds] = useState<string[]>([]);
  const [familyName, setFamilyName] = useState("");

  useEffect(() => {
    dispatch(fetchMyFacilities());
  }, [dispatch]);

  useEffect(() => {
    if (!activeFacilityId || !patientId) return;
    dispatch(fetchPatients({ facilityId: activeFacilityId }));
    dispatch(fetchPatient({ facilityId: activeFacilityId, patientId }));
    dispatch(fetchPatientFamily({ facilityId: activeFacilityId, patientId }));
  }, [dispatch, activeFacilityId, patientId]);

  const vitalAlerts = useMemo(() => {
    return (current?.vitals || []).filter((v) => v.alert);
  }, [current]);

  const otherPatients = useMemo(
    () => list.filter((p) => p._id !== patientId),
    [list, patientId]
  );

  // Oldest → newest
  const validVitals = useMemo(() => {
    return (current?.vitals || [])
      .filter((v) => v.recordedAt)
      .slice()
      .sort(
        (a, b) =>
          new Date(a.recordedAt as any).getTime() -
          new Date(b.recordedAt as any).getTime()
      );
  }, [current]);

  const sparkVitals = useMemo(() => validVitals.slice(-14), [validVitals]);
  const chartVitals = useMemo(
    () => validVitals.slice(-chartRange),
    [validVitals, chartRange]
  );
  const chartLabels = useMemo(
    () =>
      chartVitals.map((v) =>
        new Date(v.recordedAt as any).toLocaleDateString(undefined, {
          month: "short",
          day: "numeric",
        })
      ),
    [chartVitals]
  );
  const chartFullLabels = useMemo(
    () =>
      chartVitals.map((v) => new Date(v.recordedAt as any).toLocaleString()),
    [chartVitals]
  );
  const chartAlerts = useMemo(
    () => chartVitals.map((v) => !!v.alert),
    [chartVitals]
  );

  const inputStyle = {
    backgroundColor: ui.inner,
    color: ui.text,
    borderColor: "transparent",
    boxShadow: "none",
  };

  const notify = (m: string, isErr = false) => {
    if (isErr) setErr(m);
    else setMsg(m);
    setTimeout(() => {
      setMsg(null);
      setErr(null);
    }, 3000);
  };

  const reload = () => {
    if (!activeFacilityId) return;
    dispatch(fetchPatient({ facilityId: activeFacilityId, patientId }));
    dispatch(fetchPatientFamily({ facilityId: activeFacilityId, patientId }));
  };

  if (!activeFacilityId) {
    return (
      <div
        className="max-w-lg mx-auto px-4 py-16 text-center"
        style={{ color: colors.text }}
      >
        <Building2 className="mx-auto opacity-30 mb-3" size={32} />
        <p className="font-bold">Select a facility first</p>
      </div>
    );
  }

  const facilityId = activeFacilityId;

  /* ----------------------------- helpers/actions ----------------------------- */

  const askConfirm = (c: NonNullable<ConfirmState>) => setConfirm(c);

  const runConfirm = async () => {
    if (!confirm) return;
    setConfirming(true);
    try {
      await confirm.onConfirm();
    } finally {
      setConfirming(false);
      setConfirm(null);
    }
  };

  const errText = (e: unknown, fallback: string) =>
    typeof e === "string" ? e : fallback;

  const resetAllergyForm = () => {
    setEditingAllergyId(null);
    setSubstance("");
    setSeverity("moderate");
    setReaction("");
  };

  const openAddAllergy = () => {
    resetAllergyForm();
    setAllergyModalOpen(true);
  };

  const openEditAllergy = (a: any) => {
    setEditingAllergyId(a._id);
    setSubstance(a.substance || "");
    setSeverity(a.severity || "moderate");
    setReaction(a.reaction || "");
    setAllergyModalOpen(true);
  };

  const closeAllergyModal = () => {
    setAllergyModalOpen(false);
    resetAllergyForm();
  };

  const resetVitalForm = () => {
    setEditingVitalId(null);
    setTemperature("");
    setBloodOxygenSaturation("");
    setPulseRate("");
    setBloodPressureSystolic("");
    setBloodPressureDiastolic("");
  };

  const openAddVital = () => {
    resetVitalForm();
    setVitalModalOpen(true);
  };

  const openEditVital = (v: any) => {
    setEditingVitalId(v._id);
    setTemperature(v.temperatureC != null ? String(v.temperatureC) : "");
    setBloodOxygenSaturation(v.spo2 != null ? String(v.spo2) : "");
    setPulseRate(v.pulseBpm != null ? String(v.pulseBpm) : "");
    setBloodPressureSystolic(v.bpSystolic != null ? String(v.bpSystolic) : "");
    setBloodPressureDiastolic(
      v.bpDiastolic != null ? String(v.bpDiastolic) : ""
    );
    setVitalModalOpen(true);
  };

  const closeVitalModal = () => {
    setVitalModalOpen(false);
    resetVitalForm();
  };

  const group = (familyOf as any)?.familyGroup;

  const confirmRemoveAllergy = (a: any) =>
    askConfirm({
      title: "Remove allergy?",
      message: `"${a.substance}" will be permanently removed from this patient's record. This cannot be undone.`,
      confirmLabel: "Remove allergy",
      tone: "danger",
      onConfirm: async () => {
        try {
          await dispatch(
            removePatientAllergy({
              facilityId,
              patientId,
              allergyId: a._id,
            })
          ).unwrap();
          notify("Allergy removed");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed to remove"), true);
        }
      },
    });

  const confirmRemoveVital = (v: any) =>
    askConfirm({
      title: "Remove vital record?",
      message: `The vitals recorded on ${
        v.recordedAt ? new Date(v.recordedAt).toLocaleString() : "this date"
      } will be permanently deleted and removed from all charts.`,
      confirmLabel: "Remove record",
      tone: "danger",
      onConfirm: async () => {
        try {
          await dispatch(
            removePatientVital({ facilityId, patientId, vitalId: v._id })
          ).unwrap();
          notify("Vital record removed");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed to remove"), true);
        }
      },
    });

  const confirmRemoveFromGroup = () =>
    askConfirm({
      title: "Remove from family group?",
      message: `${
        current?.firstName || "This patient"
      } will no longer be linked to ${group?.name || "this family group"}.`,
      confirmLabel: "Remove from group",
      tone: "danger",
      onConfirm: async () => {
        try {
          await dispatch(
            removeFromFamilyGroup({ facilityId, patientId })
          ).unwrap();
          notify("Removed from family group");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed to remove"), true);
        }
      },
    });

  const submitAllergy = () => {
    const editing = !!editingAllergyId;
    askConfirm({
      title: editing ? "Update allergy?" : "Save allergy?",
      message: editing
        ? `Save your changes to the "${substance}" allergy record?`
        : `Add "${substance}" (${
            SEVERITY_STYLE[severity]?.label || severity
          }) to this patient's allergies?`,
      confirmLabel: editing ? "Update allergy" : "Save allergy",
      tone: "primary",
      onConfirm: async () => {
        try {
          const payload = {
            substance,
            severity,
            reaction: reaction || undefined,
          };
          if (editingAllergyId) {
            await dispatch(
              updatePatientAllergy({
                facilityId,
                patientId,
                allergyId: editingAllergyId,
                payload,
              })
            ).unwrap();
            notify("Allergy updated");
          } else {
            await dispatch(
              addPatientAllergy({ facilityId, patientId, payload })
            ).unwrap();
            notify("Allergy recorded");
          }
          closeAllergyModal();
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed"), true);
        }
      },
    });
  };

  const submitVital = () => {
    const editing = !!editingVitalId;
    const payload: Record<string, number> = {};
    if (temperature) payload.temperatureC = Number(temperature);
    if (bloodOxygenSaturation) payload.spo2 = Number(bloodOxygenSaturation);
    if (pulseRate) payload.pulseBpm = Number(pulseRate);
    if (bloodPressureSystolic)
      payload.bpSystolic = Number(bloodPressureSystolic);
    if (bloodPressureDiastolic)
      payload.bpDiastolic = Number(bloodPressureDiastolic);
    askConfirm({
      title: editing ? "Update vitals?" : "Record vitals?",
      message: editing
        ? "Save your changes to this vital record? Alerts will be re-evaluated."
        : "Add these readings to the patient's record? Abnormal values will raise an alert.",
      confirmLabel: editing ? "Update vitals" : "Record vitals",
      tone: "primary",
      onConfirm: async () => {
        try {
          if (editingVitalId) {
            const res: any = await dispatch(
              updatePatientVital({
                facilityId,
                patientId,
                vitalId: editingVitalId,
                payload,
              })
            ).unwrap();
            notify(res?.message || "Vital updated");
          } else {
            const res: any = await dispatch(
              addPatientVital({ facilityId, patientId, payload })
            ).unwrap();
            notify(res?.message || "Vital recorded");
          }
          closeVitalModal();
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed"), true);
        }
      },
    });
  };

  const submitLinkFamily = () =>
    askConfirm({
      title: "Group as family?",
      message: `Link ${famLinkIds.length} selected patient${
        famLinkIds.length > 1 ? "s" : ""
      } with ${current?.firstName || "this patient"} as one family group?`,
      confirmLabel: "Group as family",
      tone: "primary",
      onConfirm: async () => {
        try {
          await dispatch(
            linkFamily({
              facilityId,
              payload: {
                patientIds: [patientId, ...famLinkIds],
                name: familyName || undefined,
                headPatientId: patientId,
              },
            })
          ).unwrap();
          setFamLinkIds([]);
          setFamilyModalOpen(false);
          notify("Family grouped");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Link failed"), true);
        }
      },
    });

  const submitContact = () =>
    askConfirm({
      title: "Save emergency contact?",
      message: `Add ${famName} (${famRel}) as an emergency contact for this patient?`,
      confirmLabel: "Save contact",
      tone: "primary",
      onConfirm: async () => {
        try {
          await dispatch(
            addPatientFamily({
              facilityId,
              patientId,
              payload: {
                name: famName,
                relationship: famRel,
                phone: famPhone || undefined,
                isEmergencyContact: true,
                patientRef: famLinkIds[0],
              },
            })
          ).unwrap();
          setFamName("");
          setFamRel("");
          setFamPhone("");
          setFamilyModalOpen(false);
          notify("Family contact added");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed"), true);
        }
      },
    });

  const submitNote = () =>
    askConfirm({
      title: "Add chart note?",
      message: `"${noteTitle}" will be added to this patient's chart.`,
      confirmLabel: "Add note",
      tone: "primary",
      onConfirm: async () => {
        try {
          await dispatch(
            addPatientHistory({
              facilityId,
              patientId,
              payload: { title: noteTitle, detail: noteDetail, type: "note" },
            })
          ).unwrap();
          setNoteTitle("");
          setNoteDetail("");
          setChartModalOpen(false);
          notify("Chart entry added");
          reload();
        } catch (e: unknown) {
          notify(errText(e, "Failed"), true);
        }
      },
    });

  /* --------------------------------- derived -------------------------------- */

  const tabs = [
    { id: "overview" as const, label: "Overview" },
    { id: "allergies" as const, label: "Allergies" },
    { id: "vitals" as const, label: "Vitals & alerts" },
    { id: "family" as const, label: "Family" },
    { id: "chart" as const, label: "Chart & trends" },
  ];

  const titles: Record<typeof tab, string> = {
    overview: "Health overview",
    allergies: "Allergies",
    vitals: "Vitals & alerts",
    family: "Family & contacts",
    chart: "Trends & comparisons",
  };

  const tabAction =
    tab === "overview" || tab === "vitals"
      ? { label: "Record vitals", onClick: openAddVital }
      : tab === "allergies" && canManageAllergies
      ? { label: "Add allergy", onClick: openAddAllergy }
      : tab === "family"
      ? { label: "Manage family", onClick: () => setFamilyModalOpen(true) }
      : tab === "chart"
      ? { label: "Add chart note", onClick: () => setChartModalOpen(true) }
      : null;

  const contacts = (familyOf as any)?.contacts || current?.family || [];
  const latestVital: any = validVitals[validVitals.length - 1];

  const sparkSeries = (key: string): (number | null)[] =>
    sparkVitals.map((v) => {
      const x = (v as any)[key];
      return x != null ? Number(x) : null;
    });

  const seriesOf = (key: string): (number | null)[] =>
    chartVitals.map((v) => {
      const x = (v as any)[key];
      return x != null ? Number(x) : null;
    });

  const latestPrev = (key: string) => {
    const vals = validVitals
      .map((v) => (v as any)[key])
      .filter((x) => x != null)
      .map(Number);
    return {
      latest: vals.length ? vals[vals.length - 1] : null,
      previous: vals.length > 1 ? vals[vals.length - 2] : null,
    };
  };

  const byKey = (k: string) => METRICS.find((m) => m.key === k)!;

  const trendCards: {
    id: string;
    title: string;
    icon: any;
    color: string;
    unit: string;
    domain: [number, number];
    bands: [number, number][];
    series: Series[];
    latestText: string;
  }[] = [
    ...(["temperatureC", "spo2", "pulseBpm"] as const).map((k) => {
      const m = byKey(k);
      const { latest } = latestPrev(k);
      return {
        id: k,
        title: `${m.label} trend`,
        icon: m.icon,
        color: m.color,
        unit: m.unit,
        domain: m.domain,
        bands: [m.normal],
        series: [{ name: m.label, color: m.color, data: seriesOf(k) }],
        latestText: `Latest ${fmt(latest, m.unit)}`,
      };
    }),
    (() => {
      const s = byKey("bpSystolic");
      const d = byKey("bpDiastolic");
      const ls = latestPrev("bpSystolic").latest;
      const ld = latestPrev("bpDiastolic").latest;
      return {
        id: "bp",
        title: "Blood pressure trend",
        icon: Activity,
        color: s.color,
        unit: " mmHg",
        domain: [40, 180] as [number, number],
        bands: [d.normal, s.normal],
        series: [
          { name: "Systolic", color: s.color, data: seriesOf("bpSystolic") },
          { name: "Diastolic", color: d.color, data: seriesOf("bpDiastolic") },
        ],
        latestText: `Latest ${ls ?? "—"}/${ld ?? "—"} mmHg`,
      };
    })(),
  ];

  const pulse = latestPrev("pulseBpm");
  const sys = latestPrev("bpSystolic");
  const dia = latestPrev("bpDiastolic");

  const pillTab = (active: boolean) => ({
    backgroundColor: active ? PRIMARY_COLOR : ui.card,
    color: active ? "#fff" : ui.text,
  });

  /* --------------------------------- render --------------------------------- */

  return (
    <div className="mx-auto max-w-6xl px-3 sm:px-6 py-4 sm:py-6">
      <div
        className="relative rounded-[32px] p-4 sm:p-6 space-y-5"
        style={{ backgroundColor: ui.page, color: ui.text }}
      >
        {detailLoading && !current && (
          <DarkBlurOverlayLoader text="Loading patient details..." />
        )}

        {(msg || err) && (
          <div
            className="fixed right-4 top-4 rounded-2xl px-4 py-3 text-xs font-semibold animate-in fade-in slide-in-from-top-2 duration-200"
            style={{
              zIndex: 80,
              backgroundColor: ui.card,
              color: err ? "#ef4444" : "#059669",
            }}
            role="status"
          >
            {msg || err}
          </div>
        )}

        {/* Breadcrumb */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <Link
              href="/dashboard/patients"
              className="opacity-60 hover:opacity-100"
            >
              Patients
            </Link>
            <ChevronRight size={12} className="opacity-40" />
            <span className="font-semibold">
              {current ? `${current.firstName} ${current.lastName}` : "Patient"}
            </span>
          </div>
          <span
            className="rounded-full px-3 py-1.5 text-[11px] font-medium"
            style={{ backgroundColor: ui.card }}
          >
            {activeFacility?.name}
          </span>
        </div>

        {!current ? (
          <div className="py-16 text-center text-sm opacity-60">
            Patient not found
          </div>
        ) : (
          <>
            {/* Profile card */}
            <div
              className="rounded-[28px] p-5 flex flex-wrap items-center gap-5"
              style={{ backgroundColor: ui.card }}
            >
              <UserAvatar user={current} size="md" />
              <div className="grid flex-1 grid-cols-2 gap-x-8 gap-y-3 sm:grid-cols-4 min-w-[240px]">
                {[
                  {
                    k: "Name",
                    v: `${current.firstName} ${current.lastName}`,
                  },
                  { k: "MRN", v: current.mrn },
                  {
                    k: "Date of birth",
                    v: current.dateOfBirth
                      ? new Date(current.dateOfBirth).toLocaleDateString()
                      : "—",
                  },
                  { k: "Sex", v: current.gender || "—" },
                  {
                    k: "Contact",
                    v:
                      [current.countryCode, current.phone]
                        .filter(Boolean)
                        .join(" ") ||
                      current.email ||
                      "No contact",
                  },
                ].map((f) => (
                  <div key={f.k} className="min-w-0">
                    <p className="text-[11px] opacity-50">{f.k}</p>
                    <p className="truncate text-sm font-medium capitalize">
                      {f.v}
                    </p>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                {vitalAlerts.length > 0 && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-red-500/10 px-3 py-1.5 text-[11px] font-bold text-red-500">
                    <AlertTriangle size={12} /> {vitalAlerts.length} vital alert
                    {vitalAlerts.length > 1 ? "s" : ""}
                  </span>
                )}
                {(current.allergies || []).length > 0 && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-3 py-1.5 text-[11px] font-bold text-amber-600">
                    <ShieldAlert size={12} /> {(current.allergies || []).length}{" "}
                    allerg
                    {(current.allergies || []).length > 1 ? "ies" : "y"}
                  </span>
                )}
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              {tabs.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className="whitespace-nowrap rounded-full px-5 py-2.5 text-xs font-semibold transition outline-none focus:outline-none"
                  style={pillTab(tab === t.id)}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Title row */}
            <div className="flex flex-wrap items-end justify-between gap-3 pt-1">
              <h1 className="text-3xl sm:text-4xl font-normal tracking-tight">
                {titles[tab]}
              </h1>
              {tabAction && (
                <PillButton onClick={tabAction.onClick}>
                  <Plus size={14} /> {tabAction.label}
                </PillButton>
              )}
            </div>

            {/* ------------------------------ OVERVIEW ------------------------------ */}
            {tab === "overview" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <StatCard
                  icon={Heart}
                  label="Heartbeat"
                  value={pulse.latest != null ? String(pulse.latest) : "—"}
                  unit="bpm"
                  color={byKey("pulseBpm").color}
                  status={rangeStatus(byKey("pulseBpm"), pulse.latest)}
                  ui={ui}
                >
                  <Sparkline
                    id="pulse"
                    values={sparkSeries("pulseBpm")}
                    color={byKey("pulseBpm").color}
                    unit=" bpm"
                  />
                </StatCard>

                <StatCard
                  icon={Activity}
                  label="Blood pressure"
                  value={
                    sys.latest != null
                      ? `${sys.latest}/${dia.latest ?? "—"}`
                      : "—"
                  }
                  unit="mmHg"
                  color={byKey("bpSystolic").color}
                  status={rangeStatus(byKey("bpSystolic"), sys.latest)}
                  ui={ui}
                >
                  <TickBars
                    values={sparkSeries("bpSystolic")}
                    color={byKey("bpSystolic").color}
                    ui={ui}
                  />
                </StatCard>

                <StatCard
                  icon={Thermometer}
                  label="Temperature"
                  value={
                    latestPrev("temperatureC").latest != null
                      ? String(latestPrev("temperatureC").latest)
                      : "—"
                  }
                  unit="°C"
                  color={byKey("temperatureC").color}
                  status={rangeStatus(
                    byKey("temperatureC"),
                    latestPrev("temperatureC").latest
                  )}
                  ui={ui}
                >
                  <Sparkline
                    id="temp"
                    values={sparkSeries("temperatureC")}
                    color={byKey("temperatureC").color}
                    unit="°C"
                  />
                </StatCard>

                <StatCard
                  icon={Wind}
                  label="Blood oxygen (SpO2)"
                  value={
                    latestPrev("spo2").latest != null
                      ? String(latestPrev("spo2").latest)
                      : "—"
                  }
                  unit="%"
                  color={byKey("spo2").color}
                  status={rangeStatus(byKey("spo2"), latestPrev("spo2").latest)}
                  ui={ui}
                >
                  <Sparkline
                    id="spo2"
                    values={sparkSeries("spo2")}
                    color={byKey("spo2").color}
                    unit="%"
                  />
                </StatCard>

                {/* Heart-rate activity */}
                <div
                  className="relative overflow-hidden rounded-[28px] p-6 space-y-4"
                  style={{ backgroundColor: ui.card }}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium tracking-tight">
                      Heart-rate activity
                    </h3>
                    {latestVital?.recordedAt && (
                      <span className="text-[11px] opacity-50">
                        {new Date(latestVital.recordedAt).toLocaleString()}
                      </span>
                    )}
                  </div>
                  <p className="max-w-[16rem] text-xs opacity-60">
                    A normal adult resting heart rate is 60–100 beats per
                    minute.
                  </p>
                  <div className="flex items-end justify-between gap-4">
                    <p className="text-5xl font-medium tracking-tight">
                      {pulse.latest ?? "—"}
                      <span className="ml-1.5 text-base font-normal opacity-50">
                        bpm
                      </span>
                    </p>
                    <Heart
                      size={64}
                      fill="#ef4444"
                      color="#ef4444"
                      className="shrink-0 opacity-90"
                    />
                  </div>
                  <RangeGauge
                    metric={byKey("pulseBpm")}
                    latest={pulse.latest}
                    previous={pulse.previous}
                    ui={ui}
                    large
                  />
                  <div className="flex justify-between text-[10px] opacity-50">
                    <span>40 bpm</span>
                    <span>Normal 60–100 bpm</span>
                    <span>140 bpm</span>
                  </div>
                </div>

                {/* Alerts */}
                <div
                  className="rounded-[28px] p-6 space-y-3"
                  style={{ backgroundColor: ui.card }}
                >
                  <h3 className="text-lg font-medium tracking-tight">
                    Latest vital alerts
                  </h3>
                  {vitalAlerts.length === 0 ? (
                    <div
                      className="flex items-center gap-3 rounded-2xl p-4 text-xs"
                      style={{ backgroundColor: ui.inner }}
                    >
                      <ShieldCheck size={18} className="text-emerald-500" />
                      <span className="opacity-70">
                        No alerts. All recorded vitals are within range.
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {vitalAlerts
                        .slice(-4)
                        .reverse()
                        .map((v, i) => (
                          <div
                            key={v._id || i}
                            className="flex items-start gap-3 rounded-2xl p-3.5"
                            style={{ backgroundColor: "rgba(239,68,68,0.08)" }}
                          >
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-500/15 text-red-500">
                              <AlertTriangle size={16} />
                            </span>
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-red-500">
                                {v.alertReason}
                              </p>
                              <p className="text-[10px] opacity-50 mt-0.5">
                                {v.recordedAt
                                  ? new Date(v.recordedAt).toLocaleString()
                                  : ""}
                              </p>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Allergies */}
                <div
                  className="rounded-[28px] p-6 space-y-3"
                  style={{ backgroundColor: ui.card }}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium tracking-tight">
                      Allergies
                    </h3>
                    <button
                      type="button"
                      onClick={() => setTab("allergies")}
                      className="text-[11px] font-semibold opacity-60 hover:opacity-100"
                    >
                      View all
                    </button>
                  </div>
                  {(current.allergies || []).length === 0 ? (
                    <p className="text-xs opacity-40">None recorded</p>
                  ) : (
                    <div className="space-y-2">
                      {(current.allergies || [])
                        .slice(0, 3)
                        .map((a: any, i: number) => (
                          <AllergyCard
                            key={a._id || i}
                            a={a}
                            canManage={canManageAllergies}
                            onEdit={() => openEditAllergy(a)}
                            onDelete={() => confirmRemoveAllergy(a)}
                            bg={ui.inner}
                          />
                        ))}
                    </div>
                  )}
                </div>

                {/* Family */}
                <div
                  className="rounded-[28px] p-6 space-y-3"
                  style={{ backgroundColor: ui.card }}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="flex items-center gap-2 text-lg font-medium tracking-tight">
                      <Users size={16} /> Family group
                    </h3>
                    <button
                      type="button"
                      onClick={() => setFamilyModalOpen(true)}
                      className="text-[11px] font-semibold opacity-60 hover:opacity-100"
                    >
                      Manage
                    </button>
                  </div>
                  {group ? (
                    <div className="space-y-2">
                      <p className="text-xs font-semibold">
                        {group.name || "Family"}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {(group.members || []).map((m: any) => (
                          <Link
                            key={m._id}
                            href={`/dashboard/patients/${m._id}`}
                            className="inline-flex items-center gap-1.5 rounded-full py-1 pl-1 pr-3 text-xs"
                            style={{ backgroundColor: ui.inner }}
                          >
                            <UserAvatar user={m} size="sm" />
                            {personLabel(m)}
                          </Link>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs opacity-40">
                      Not linked to a registered family group
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* ------------------------------ ALLERGIES ----------------------------- */}
            {tab === "allergies" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(current.allergies || []).length === 0 ? (
                  <div
                    className="rounded-[28px] p-8 text-center text-xs opacity-60 sm:col-span-2"
                    style={{ backgroundColor: ui.card }}
                  >
                    No allergies recorded.
                  </div>
                ) : (
                  (current.allergies || []).map((a: any, i: number) => (
                    <AllergyCard
                      key={a._id || i}
                      a={a}
                      canManage={canManageAllergies}
                      onEdit={() => openEditAllergy(a)}
                      onDelete={() => confirmRemoveAllergy(a)}
                      bg={ui.card}
                    />
                  ))
                )}
              </div>
            )}

            {/* ------------------------------- VITALS ------------------------------- */}
            {tab === "vitals" && (
              <div className="space-y-4">
                {vitalAlerts.length > 0 && (
                  <div
                    className="rounded-[28px] p-5 space-y-3"
                    style={{ backgroundColor: ui.card }}
                  >
                    <p className="flex items-center gap-2 text-sm font-semibold text-red-500">
                      <AlertTriangle size={16} /> Alerts for this patient
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {vitalAlerts
                        .slice()
                        .reverse()
                        .map((v, i) => (
                          <div
                            key={v._id || i}
                            className="rounded-2xl p-3.5 text-xs space-y-1"
                            style={{ backgroundColor: "rgba(239,68,68,0.08)" }}
                          >
                            <p className="font-semibold text-red-500">
                              {v.alertReason}
                            </p>
                            <p className="opacity-70">
                              {v.temperatureC != null
                                ? `Temp ${v.temperatureC}°C · `
                                : ""}
                              {v.spo2 != null ? `SpO2 ${v.spo2}% · ` : ""}
                              {v.pulseBpm != null
                                ? `Pulse ${v.pulseBpm} bpm · `
                                : ""}
                              {v.bpSystolic != null
                                ? `BP ${v.bpSystolic}/${
                                    v.bpDiastolic ?? "—"
                                  } mmHg`
                                : ""}
                            </p>
                            <p className="text-[10px] opacity-40">
                              {v.recordedAt
                                ? new Date(v.recordedAt).toLocaleString()
                                : ""}
                            </p>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                  {(current.vitals || []).length === 0 ? (
                    <div
                      className="rounded-[28px] p-8 text-center text-xs opacity-60 lg:col-span-2"
                      style={{ backgroundColor: ui.card }}
                    >
                      No vitals recorded.
                    </div>
                  ) : (
                    (current.vitals || [])
                      .slice()
                      .reverse()
                      .map((v, i) => (
                        <div
                          key={v._id || i}
                          className="rounded-[28px] p-5 space-y-3"
                          style={{ backgroundColor: ui.card }}
                        >
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-medium opacity-60">
                              {v.recordedAt
                                ? new Date(v.recordedAt).toLocaleString()
                                : "—"}
                            </span>
                            <div className="flex items-center gap-1.5">
                              {v.alert && (
                                <span className="rounded-full bg-red-500/10 px-2.5 py-1 text-[10px] font-bold text-red-500">
                                  Alert
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={() => openEditVital(v)}
                                className="flex h-8 w-8 items-center justify-center rounded-full opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition outline-none focus:outline-none"
                                title="Edit vitals"
                                aria-label="Edit vitals"
                              >
                                <Edit3 size={14} />
                              </button>
                              <button
                                type="button"
                                onClick={() => confirmRemoveVital(v)}
                                className="flex h-8 w-8 items-center justify-center rounded-full opacity-60 hover:opacity-100 hover:bg-red-500/10 hover:text-red-500 transition outline-none focus:outline-none"
                                title="Remove vitals"
                                aria-label="Remove vitals"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <VitalTile
                              label="Temperature"
                              value={fmt(v.temperatureC, "°C")}
                              icon={Thermometer}
                              color="#f97316"
                              ui={ui}
                            />
                            <VitalTile
                              label="Blood oxygen"
                              value={fmt(v.spo2, "%")}
                              icon={Wind}
                              color="#3b82f6"
                              ui={ui}
                            />
                            <VitalTile
                              label="Pulse rate"
                              value={fmt(v.pulseBpm, " bpm")}
                              icon={Heart}
                              color="#ec4899"
                              ui={ui}
                            />
                            <VitalTile
                              label="Blood pressure"
                              value={
                                v.bpSystolic != null
                                  ? `${v.bpSystolic}/${v.bpDiastolic ?? "—"}`
                                  : "—"
                              }
                              icon={Activity}
                              color="#10b981"
                              ui={ui}
                            />
                          </div>
                          {v.alertReason && (
                            <p className="text-[11px] font-semibold text-red-500">
                              Reason: {v.alertReason}
                            </p>
                          )}
                        </div>
                      ))
                  )}
                </div>
              </div>
            )}

            {/* ------------------------------- FAMILY ------------------------------- */}
            {tab === "family" && (
              <div className="space-y-4">
                {group && (
                  <div
                    className="rounded-[28px] p-5 space-y-3"
                    style={{ backgroundColor: ui.card }}
                  >
                    <p className="text-sm font-semibold">{group.name}</p>
                    <div className="flex flex-wrap gap-2">
                      {(group.members || []).map((m: any) => (
                        <Link
                          key={m._id}
                          href={`/dashboard/patients/${m._id}`}
                          className="inline-flex items-center gap-1.5 rounded-full py-1 pl-1 pr-3 text-xs"
                          style={{ backgroundColor: ui.inner }}
                        >
                          <UserAvatar user={m} size="sm" />
                          {personLabel(m)} · {m.mrn}
                        </Link>
                      ))}
                    </div>
                    <button
                      type="button"
                      onClick={confirmRemoveFromGroup}
                      className="text-xs font-semibold text-red-500 outline-none focus:outline-none"
                    >
                      Remove this patient from group
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(contacts as any[]).length === 0 ? (
                    <div
                      className="rounded-[28px] p-8 text-center text-xs opacity-60 sm:col-span-2"
                      style={{ backgroundColor: ui.card }}
                    >
                      No family or emergency contacts recorded.
                    </div>
                  ) : (
                    (contacts as any[]).map((c, i) => (
                      <div
                        key={c._id || i}
                        className="rounded-[28px] p-5 space-y-2"
                        style={{ backgroundColor: ui.card }}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold">
                            {c.name}
                          </span>
                          {c.isEmergencyContact && (
                            <span className="rounded-full bg-red-500/10 px-2.5 py-1 text-[10px] font-bold text-red-500">
                              Emergency
                            </span>
                          )}
                        </div>
                        <p className="text-xs opacity-70 capitalize">
                          Relationship: {c.relationship}
                        </p>
                        {c.phone && (
                          <p className="text-xs opacity-70">
                            Phone: {c.countryCode || ""} {c.phone}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* ---------------------------- CHART & TRENDS --------------------------- */}
            {tab === "chart" && (
              <div className="space-y-5">
                {/* Controls */}
                <div className="flex flex-wrap items-center gap-2">
                  {([6, 12, 24] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setChartRange(r)}
                      className="rounded-full px-4 py-2 text-xs font-semibold outline-none focus:outline-none"
                      style={pillTab(chartRange === r)}
                    >
                      Last {r}
                    </button>
                  ))}
                  <span className="mx-1 h-5 w-px bg-current opacity-15" />
                  {(
                    [
                      { id: "line", label: "Line", icon: LineChartIcon },
                      { id: "bar", label: "Bars", icon: BarChart3 },
                    ] as const
                  ).map((o) => (
                    <button
                      key={o.id}
                      type="button"
                      onClick={() => setChartView(o.id)}
                      className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold outline-none focus:outline-none"
                      style={pillTab(chartView === o.id)}
                    >
                      <o.icon size={13} /> {o.label}
                    </button>
                  ))}
                </div>

                {validVitals.length === 0 ? (
                  <div
                    className="rounded-[28px] p-8 text-center text-xs opacity-60"
                    style={{ backgroundColor: ui.card }}
                  >
                    No vital records yet. Record vitals to see trends.
                  </div>
                ) : (
                  <>
                    <div>
                      <div className="mb-2 flex flex-wrap items-center justify-between gap-2 px-1">
                        <h2 className="text-sm font-semibold">
                          Latest vs previous vs normal range
                        </h2>
                        <div className="flex items-center gap-3 text-[10px] opacity-60">
                          <span className="inline-flex items-center gap-1">
                            <span className="h-2.5 w-2.5 rounded-full bg-current" />
                            Latest
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <span className="h-2.5 w-2.5 rounded-full border-2 border-current" />
                            Previous
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <span
                              className="h-2.5 w-4 rounded-full"
                              style={{
                                background:
                                  "linear-gradient(90deg,#fde68a,#34d399)",
                              }}
                            />
                            Normal
                          </span>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        {METRICS.map((m) => {
                          const { latest, previous } = latestPrev(m.key);
                          return (
                            <MetricSnapshot
                              key={m.key}
                              metric={m}
                              latest={latest}
                              previous={previous}
                              ui={ui}
                            />
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <h2 className="mb-2 px-1 text-sm font-semibold">
                        Trends over the last {chartVitals.length} readings
                      </h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {trendCards.map((c) => {
                          const Icon = c.icon;
                          return (
                            <div
                              key={c.id}
                              className="rounded-[28px] p-5 space-y-3"
                              style={{ backgroundColor: ui.card }}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-3">
                                  <span
                                    className="flex h-10 w-10 items-center justify-center rounded-2xl"
                                    style={{
                                      backgroundColor: ui.inner,
                                      color: c.color,
                                    }}
                                  >
                                    <Icon size={17} />
                                  </span>
                                  <div>
                                    <p className="text-sm font-medium">
                                      {c.title}
                                    </p>
                                    <p className="text-[11px] opacity-55">
                                      {c.latestText}
                                    </p>
                                  </div>
                                </div>
                                {c.series.length > 1 && (
                                  <div className="flex gap-3 text-[10px] opacity-70">
                                    {c.series.map((s) => (
                                      <span
                                        key={s.name}
                                        className="inline-flex items-center gap-1"
                                      >
                                        <span
                                          className="h-2 w-2 rounded-full"
                                          style={{ backgroundColor: s.color }}
                                        />
                                        {s.name}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <TrendChart
                                id={c.id}
                                labels={chartLabels}
                                fullLabels={chartFullLabels}
                                series={c.series}
                                domain={c.domain}
                                bands={c.bands}
                                mode={chartView}
                                alerts={chartAlerts}
                                unit={c.unit}
                                grid={ui.border}
                              />
                            </div>
                          );
                        })}
                      </div>
                      <p className="mt-2 px-1 text-[10px] opacity-50">
                        The green band marks the normal range. Red points and
                        bars are readings that raised an alert. Hover a point or
                        bar for the exact value and time.
                      </p>
                    </div>

                    {/* Table */}
                    <div
                      className="rounded-[28px] p-5 space-y-3"
                      style={{ backgroundColor: ui.card }}
                    >
                      <h3 className="text-sm font-semibold">
                        All recorded sessions
                      </h3>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="opacity-50">
                              <th className="pb-2.5 pr-3 font-medium">
                                Recorded
                              </th>
                              <th className="pb-2.5 pr-3 font-medium">
                                Temperature
                              </th>
                              <th className="pb-2.5 pr-3 font-medium">SpO2</th>
                              <th className="pb-2.5 pr-3 font-medium">Pulse</th>
                              <th className="pb-2.5 pr-3 font-medium">
                                Blood pressure
                              </th>
                              <th className="pb-2.5 font-medium">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {validVitals
                              .slice()
                              .reverse()
                              .map((v, idx) => (
                                <tr
                                  key={v._id || idx}
                                  className="border-t"
                                  style={{ borderColor: ui.border }}
                                >
                                  <td className="py-3 pr-3 font-medium whitespace-nowrap">
                                    {new Date(
                                      v.recordedAt as any
                                    ).toLocaleString()}
                                  </td>
                                  <td className="py-3 pr-3">
                                    {fmt(v.temperatureC, "°C")}
                                  </td>
                                  <td className="py-3 pr-3">
                                    {fmt(v.spo2, "%")}
                                  </td>
                                  <td className="py-3 pr-3">
                                    {fmt(v.pulseBpm, " bpm")}
                                  </td>
                                  <td className="py-3 pr-3 whitespace-nowrap">
                                    {v.bpSystolic != null
                                      ? `${v.bpSystolic}/${
                                          v.bpDiastolic ?? "—"
                                        } mmHg`
                                      : "—"}
                                  </td>
                                  <td className="py-3">
                                    {v.alert ? (
                                      <span className="inline-flex items-center gap-1 rounded-full bg-red-500/10 px-2.5 py-1 text-[10px] font-bold text-red-500">
                                        <AlertTriangle size={10} />{" "}
                                        {v.alertReason || "Abnormal"}
                                      </span>
                                    ) : (
                                      <span className="rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-semibold text-emerald-600">
                                        Normal
                                      </span>
                                    )}
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </>
                )}

                {/* Chart notes */}
                <div className="space-y-2">
                  <h2 className="px-1 text-sm font-semibold">Chart notes</h2>
                  {(current.medicalHistory || []).length === 0 ? (
                    <div
                      className="rounded-[28px] p-6 text-center text-xs opacity-60"
                      style={{ backgroundColor: ui.card }}
                    >
                      No chart notes recorded.
                    </div>
                  ) : (
                    (current.medicalHistory || [])
                      .slice()
                      .reverse()
                      .map((h, i) => (
                        <div
                          key={h._id || i}
                          className="rounded-2xl px-5 py-4 text-xs"
                          style={{ backgroundColor: ui.card }}
                        >
                          <p className="text-sm font-semibold">{h.title}</p>
                          {h.detail && (
                            <p className="mt-1 opacity-70">{h.detail}</p>
                          )}
                          <p className="mt-2 text-[11px] opacity-40">
                            {h.type} ·{" "}
                            {h.at ? new Date(h.at).toLocaleString() : ""}
                          </p>
                        </div>
                      ))
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* ----------------------------- Modal: Allergy ---------------------------- */}
      <Modal
        open={allergyModalOpen}
        title={editingAllergyId ? "Edit allergy" : "Add allergy"}
        onClose={closeAllergyModal}
        escape={!confirm}
        ui={ui}
      >
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            submitAllergy();
          }}
        >
          <div>
            <label className="mb-1.5 block text-xs font-medium opacity-60">
              Substance *
            </label>
            <input
              required
              value={substance}
              onChange={(e) => setSubstance(e.target.value)}
              placeholder="e.g. Penicillin, Peanuts"
              className={inputCls}
              style={inputStyle}
            />
          </div>
          <CustomDropdown
            label="Severity"
            value={severity}
            options={[
              { value: "mild", label: "Mild" },
              { value: "moderate", label: "Moderate" },
              { value: "severe", label: "Severe" },
              { value: "life_threatening", label: "Life-threatening" },
            ]}
            onChange={setSeverity}
            isDark={isDark}
            colors={colors}
            border={border}
          />
          <div>
            <label className="mb-1.5 block text-xs font-medium opacity-60">
              Reaction
            </label>
            <input
              value={reaction}
              onChange={(e) => setReaction(e.target.value)}
              placeholder="e.g. Hives, Anaphylaxis"
              className={inputCls}
              style={inputStyle}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={closeAllergyModal}
              className="rounded-full px-5 py-2.5 text-xs font-semibold outline-none focus:outline-none"
              style={{ backgroundColor: ui.inner }}
            >
              Cancel
            </button>
            <PillButton type="submit" disabled={saving}>
              {saving
                ? "Saving..."
                : editingAllergyId
                ? "Update allergy"
                : "Save allergy"}
            </PillButton>
          </div>
        </form>
      </Modal>

      {/* ------------------------------ Modal: Vitals ---------------------------- */}
      <Modal
        open={vitalModalOpen}
        title={editingVitalId ? "Edit vitals" : "Record vitals"}
        onClose={closeVitalModal}
        escape={!confirm}
        ui={ui}
      >
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            submitVital();
          }}
        >
          <div className="space-y-3">
            <div>
              <label className="mb-1.5 block text-xs font-medium opacity-80">
                Temperature (°C)
              </label>
              <input
                value={temperature}
                onChange={(e) => setTemperature(e.target.value)}
                placeholder="e.g. 36.6"
                inputMode="decimal"
                className={inputCls}
                style={inputStyle}
              />
              <p className="text-[10px] opacity-50 mt-1">
                Normal resting range is 36.5°C to 37.5°C.
              </p>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium opacity-80">
                Blood Oxygen Saturation (%)
              </label>
              <input
                value={bloodOxygenSaturation}
                onChange={(e) => setBloodOxygenSaturation(e.target.value)}
                placeholder="e.g. 98"
                inputMode="decimal"
                className={inputCls}
                style={inputStyle}
              />
              <p className="text-[10px] opacity-50 mt-1">
                Normal healthy range is 95% to 100%.
              </p>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium opacity-80">
                Pulse Rate (Beats Per Minute)
              </label>
              <input
                value={pulseRate}
                onChange={(e) => setPulseRate(e.target.value)}
                placeholder="e.g. 75"
                inputMode="numeric"
                className={inputCls}
                style={inputStyle}
              />
              <p className="text-[10px] opacity-50 mt-1">
                Normal resting adult heart rate is 60 to 100 beats per minute.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium opacity-80">
                  Systolic Pressure (mmHg)
                </label>
                <input
                  value={bloodPressureSystolic}
                  onChange={(e) => setBloodPressureSystolic(e.target.value)}
                  placeholder="e.g. 120"
                  inputMode="numeric"
                  className={inputCls}
                  style={inputStyle}
                />
                <p className="text-[10px] opacity-50 mt-1">
                  Upper number. Normal is below 120 mmHg.
                </p>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium opacity-80">
                  Diastolic Pressure (mmHg)
                </label>
                <input
                  value={bloodPressureDiastolic}
                  onChange={(e) => setBloodPressureDiastolic(e.target.value)}
                  placeholder="e.g. 80"
                  inputMode="numeric"
                  className={inputCls}
                  style={inputStyle}
                />
                <p className="text-[10px] opacity-50 mt-1">
                  Lower number. Normal is below 80 mmHg.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={closeVitalModal}
              className="rounded-full px-5 py-2.5 text-xs font-semibold outline-none focus:outline-none"
              style={{ backgroundColor: ui.inner }}
            >
              Cancel
            </button>
            <PillButton type="submit" disabled={saving}>
              {saving
                ? "Saving..."
                : editingVitalId
                ? "Update vitals"
                : "Record vitals"}
            </PillButton>
          </div>
        </form>
      </Modal>

      {/* ------------------------------ Modal: Family ---------------------------- */}
      <Modal
        open={familyModalOpen}
        title="Manage family & contacts"
        onClose={() => setFamilyModalOpen(false)}
        escape={!confirm}
        ui={ui}
      >
        <div className="space-y-5">
          <div className="space-y-3">
            <p className="text-xs font-semibold opacity-70">
              Link registered patients as a family group
            </p>
            <CustomSearchableMultiSelect
              label="Select relatives"
              value={famLinkIds}
              items={otherPatients}
              onChange={setFamLinkIds}
              placeholder="Search patients…"
              searchPlaceholder="Search by name or MRN…"
              isDark={isDark}
              colors={colors}
              border={border}
            />
            <input
              value={familyName}
              onChange={(e) => setFamilyName(e.target.value)}
              placeholder="Family group name (optional)"
              className={inputCls}
              style={inputStyle}
            />
            <button
              type="button"
              disabled={saving || famLinkIds.length < 1}
              onClick={submitLinkFamily}
              className="w-full rounded-full px-5 py-3 text-xs font-semibold text-white disabled:opacity-50 outline-none focus:outline-none"
              style={{ backgroundColor: PRIMARY_COLOR }}
            >
              Group as family
            </button>
          </div>

          <div
            className="border-t pt-4 space-y-3"
            style={{ borderColor: ui.border }}
          >
            <p className="text-xs font-semibold opacity-70">
              Add emergency / custom contact
            </p>
            <form
              className="space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                submitContact();
              }}
            >
              <input
                required
                value={famName}
                onChange={(e) => setFamName(e.target.value)}
                placeholder="Contact name *"
                className={inputCls}
                style={inputStyle}
              />
              <input
                required
                value={famRel}
                onChange={(e) => setFamRel(e.target.value)}
                placeholder="Relationship (e.g. Spouse) *"
                className={inputCls}
                style={inputStyle}
              />
              <input
                value={famPhone}
                onChange={(e) => setFamPhone(e.target.value)}
                placeholder="Phone number"
                className={inputCls}
                style={inputStyle}
              />
              <button
                type="submit"
                className="w-full rounded-full px-5 py-3 text-xs font-semibold text-white outline-none focus:outline-none"
                style={{ backgroundColor: PRIMARY_COLOR }}
              >
                Save contact
              </button>
            </form>
          </div>
        </div>
      </Modal>

      {/* ---------------------------- Modal: Chart note -------------------------- */}
      <Modal
        open={chartModalOpen}
        title="Add chart note"
        onClose={() => setChartModalOpen(false)}
        escape={!confirm}
        ui={ui}
      >
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            submitNote();
          }}
        >
          <div>
            <label className="mb-1.5 block text-xs font-medium opacity-60">
              Title *
            </label>
            <input
              required
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              placeholder="Note title"
              className={inputCls}
              style={inputStyle}
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium opacity-60">
              Detail
            </label>
            <textarea
              value={noteDetail}
              onChange={(e) => setNoteDetail(e.target.value)}
              rows={3}
              placeholder="Detailed medical observations..."
              className={inputCls}
              style={inputStyle}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setChartModalOpen(false)}
              className="rounded-full px-5 py-2.5 text-xs font-semibold outline-none focus:outline-none"
              style={{ backgroundColor: ui.inner }}
            >
              Cancel
            </button>
            <PillButton type="submit">Save note</PillButton>
          </div>
        </form>
      </Modal>

      {/* --------------------------- Confirmation modal -------------------------- */}
      <ConfirmModal
        state={confirm}
        busy={confirming}
        onCancel={() => setConfirm(null)}
        onConfirm={runConfirm}
        ui={ui}
      />
    </div>
  );
}
