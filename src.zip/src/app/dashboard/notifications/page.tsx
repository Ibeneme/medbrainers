"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bell,
  Check,
  CheckCheck,
  ChevronRight,
  Filter,
  Loader2,
  RefreshCw,
  Trash2,
  AlertTriangle,
  Info,
  Sparkles,
  Siren,
  Search,
} from "lucide-react";
import { useTheme } from "@/contexts/theme-context";
import { useAppDispatch, useAppSelector } from "@/api/hooks";
import {
  dismissNotifications,
  fetchNotifications,
  fetchMoreNotifications,
  markAllNotificationsRead,
  markNotificationsRead,
  selectNotifications,
  selectUnreadTotal,
  type AppNotification,
  type NotificationModule,
  type NotificationSeverity,
} from "@/api/slices/notificationsSlice";
import { T, useT } from "@/i18n/provider";
import { ToggleSwitch } from "@/components/ui/items";

const MODULES: { id: NotificationModule | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "patients", label: "Patients" },
  { id: "clinical", label: "Clinical" },
  { id: "labs", label: "Labs" },
  { id: "radiology", label: "Radiology" },
  { id: "pharmacy", label: "Pharmacy" },
  { id: "emergency", label: "Emergency" },
  { id: "wards", label: "Wards" },
  { id: "maternity", label: "Maternity" },
  { id: "theater", label: "Theater" },
  { id: "blood_bank", label: "Blood Bank" },
  { id: "tasks", label: "Tasks" },
  { id: "telemedicine", label: "Telemedicine" },
  { id: "company", label: "Company" },
  { id: "system", label: "System" },
];

function severityIcon(sev: NotificationSeverity) {
  switch (sev) {
    case "critical":
      return <Siren size={15} className="animate-pulse" />;
    case "warning":
      return <AlertTriangle size={15} />;
    case "success":
      return <Sparkles size={15} />;
    default:
      return <Info size={15} />;
  }
}

function severityColor(sev: NotificationSeverity, primary: string) {
  switch (sev) {
    case "critical":
      return "#EF4444";
    case "warning":
      return "#F59E0B";
    case "success":
      return "#22C55E";
    default:
      return primary;
  }
}

function relativeTime(iso: string) {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "";
  const diff = Date.now() - t;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "Just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString();
}

function deepLink(n: AppNotification): string | null {
  const patientId = n.entity?.patientId;
  if (patientId) return `/dashboard/patients/${patientId}`;
  if (n.module === "labs") return "/dashboard/labs";
  if (n.module === "radiology") return "/dashboard/radiology/requests";
  if (n.module === "pharmacy") return "/dashboard/pharmacy";
  if (n.module === "emergency") return "/dashboard/emergency";
  if (n.module === "wards") return "/dashboard/wards";
  if (n.module === "tasks") return "/dashboard/tasks";
  if (n.module === "telemedicine") return "/dashboard/telemedicine";
  return null;
}

export default function NotificationsPage() {
  const t = useT();
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { theme, colors, primaryColor } = useTheme();
  const items = useAppSelector(selectNotifications);
  const unreadTotal = useAppSelector(selectUnreadTotal);
  const { listLoading, loadingMore, hasMore, saving, error } = useAppSelector(
    (s) => s.notifications
  );
  const activeFacilityId = useAppSelector((s) => s.facilities.activeFacilityId);

  const [module, setModule] = useState<NotificationModule | "all">("all");
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const border =
    theme === "dark" ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)";
  const cardBg = theme === "dark" ? "rgba(255,255,255,0.02)" : "#ffffff";

  const load = (opts?: {
    module?: NotificationModule | "all";
    unreadOnly?: boolean;
  }) => {
    const m = opts?.module ?? module;
    const u = opts?.unreadOnly ?? unreadOnly;
    dispatch(
      fetchNotifications({
        facilityId: activeFacilityId || null,
        module: m === "all" ? null : m,
        unreadOnly: u,
        limit: 40,
      })
    );
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeFacilityId]);

  const filteredItems = useMemo(() => {
    if (!searchQuery.trim()) return items;
    const q = searchQuery.toLowerCase();
    return items.filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        (n.body && n.body.toLowerCase().includes(q)) ||
        n.module.toLowerCase().includes(q)
    );
  }, [items, searchQuery]);

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const onMarkSelectedRead = async () => {
    if (!selected.size) return;
    await dispatch(markNotificationsRead({ ids: Array.from(selected) }));
    setSelected(new Set());
  };

  const onDismissSelected = async () => {
    if (!selected.size) return;
    await dispatch(dismissNotifications({ ids: Array.from(selected) }));
    setSelected(new Set());
  };

  const onMarkAll = async () => {
    await dispatch(
      markAllNotificationsRead({
        facilityId: activeFacilityId || null,
        module: module === "all" ? undefined : module,
      })
    );
  };

  const onOpen = async (n: AppNotification) => {
    if (!n.read) {
      dispatch(markNotificationsRead({ ids: [n.id] }));
    }
    const href = deepLink(n);
    if (href) router.push(href);
  };

  const empty = !listLoading && filteredItems.length === 0;

  return (
    <div className="w-full max-w-6xl mx-auto space-y-4 sm:space-y-6 px-3 sm:px-0 pb-12">
      {/* Top Header Banner */}
      <div
        className="relative overflow-hidden p-4 sm:p-6 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        style={{ borderColor: border, backgroundColor: cardBg }}
      >
        <div className="flex items-center gap-3.5 min-w-0">
          <div
            className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-white  shrink-0"
            style={{ backgroundColor: primaryColor }}
          >
            <Bell size={22} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-lg sm:text-xl font-extrabold tracking-tight truncate">
                <T>Notifications Hub</T>
              </h1>
              {unreadTotal > 0 && (
                <span
                  className="px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold text-white animate-pulse"
                  style={{ backgroundColor: primaryColor }}
                >
                  {unreadTotal} new
                </span>
              )}
            </div>
            <p className="text-xs opacity-70 mt-0.5 truncate">
              {unreadTotal > 0 ? (
                <T>
                  You have active unread clinical alerts requiring attention
                </T>
              ) : (
                <T>All systems normal — you&apos;re completely caught up</T>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
          <button
            type="button"
            onClick={() => load()}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all hover:opacity-80 "
            style={{
              borderColor: border,
              backgroundColor: colors.shadeBgSecond,
            }}
          >
            <RefreshCw
              size={14}
              className={listLoading ? "animate-spin" : ""}
            />
            <T>Refresh</T>
          </button>
          <button
            type="button"
            onClick={onMarkAll}
            disabled={saving || unreadTotal === 0}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white disabled:opacity-40 transition-all hover:opacity-90"
            style={{ backgroundColor: primaryColor }}
          >
            <CheckCheck size={14} />
            <T>Mark all read</T>
          </button>
        </div>
      </div>

      {/* Control Filter Bar */}
      <div
        className="flex flex-col gap-3.5 p-3.5 sm:p-4 rounded-2xl border "
        style={{ borderColor: border, backgroundColor: cardBg }}
      >
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative w-full sm:max-w-md">
            <Search
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 opacity-50"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notifications..."
              className="w-full pl-10 pr-4 py-2 rounded-xl text-xs border bg-transparent outline-none transition-colors focus:ring-1"
              style={{ borderColor: border, color: colors.text }}
            />
          </div>
          <div className="flex items-center justify-between sm:justify-end gap-3">
            <ToggleSwitch
              checked={unreadOnly}
              onChange={(checked) => {
                setUnreadOnly(checked);
                load({ unreadOnly: checked });
              }}
              label={t("Unread only")}
            />
          </div>
        </div>

        {/* Categories / Modules Pill Scroll Container */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none w-full">
          <span className="flex items-center gap-1 text-xs font-semibold opacity-60 mr-1 shrink-0">
            <Filter size={13} />
            <T>Module:</T>
          </span>
          {MODULES.map((m) => {
            const active = module === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setModule(m.id);
                  load({ module: m.id });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-medium border transition-all shrink-0"
                style={{
                  borderColor: active ? primaryColor : border,
                  backgroundColor: active ? primaryColor : "transparent",
                  color: active ? "#fff" : colors.text,
               
                }}
              >
                {t(m.label)}
              </button>
            );
          })}
        </div>
      </div>

      {/* Batch Actions Bar (Conditionally Displayed) */}
      {selected.size > 0 && (
        <div
          className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 px-4 py-3 rounded-xl border text-xs font-semibold "
          style={{ borderColor: border, backgroundColor: colors.shadeBgSecond }}
        >
          <div className="flex items-center gap-2">
            <span
              className="w-6 h-6 rounded-lg flex items-center justify-center text-white"
              style={{ backgroundColor: primaryColor }}
            >
              {selected.size}
            </span>
            <span>
              <T>notifications selected</T>
            </span>
          </div>
          <div className="flex items-center gap-2 justify-end">
            <button
              type="button"
              onClick={onMarkSelectedRead}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors hover:opacity-80"
              style={{ borderColor: border, backgroundColor: cardBg }}
            >
              <Check size={13} /> <T>Mark read</T>
            </button>
            <button
              type="button"
              onClick={onDismissSelected}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border text-red-500 transition-colors hover:bg-red-500/10"
              style={{ borderColor: border, backgroundColor: cardBg }}
            >
              <Trash2 size={13} /> <T>Dismiss</T>
            </button>
          </div>
        </div>
      )}

      {error && <div className="text-sm text-red-500 px-1">{error}</div>}

      {/* Notifications Card List Container */}
      <div
        className="rounded-2xl border overflow-hidden "
        style={{ borderColor: border, backgroundColor: cardBg }}
      >
        {listLoading && items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-70 gap-3 text-sm">
            <Loader2 size={24} className="animate-spin" />
            <T>Loading notifications…</T>
          </div>
        ) : empty ? (
          <div className="flex flex-col items-center justify-center py-20 px-4 text-center gap-3 opacity-60">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ backgroundColor: colors.shadeBgSecond }}
            >
              <Bell size={32} />
            </div>
            <p className="text-base font-semibold">
              <T>No notifications found</T>
            </p>
            <p className="text-xs max-w-xs opacity-70">
              <T>
                Critical alerts from emergency, labs, and clinical care will
                appear here instantly.
              </T>
            </p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: border }}>
            {filteredItems.map((n) => {
              const sev = severityColor(n.severity, primaryColor);
              const href = deepLink(n);
              const isSel = selected.has(n.id);
              return (
                <div
                  key={n.id}
                  className="flex items-start gap-3 sm:gap-4 p-3.5 sm:p-4 transition-all hover:opacity-100 group"
                  style={{
                    backgroundColor: n.read
                      ? "transparent"
                      : theme === "dark"
                      ? "rgba(255,255,255,0.02)"
                      : "rgba(0,0,0,0.015)",
                    borderLeft: !n.read
                      ? `4px solid ${primaryColor}`
                      : "4px solid transparent",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={isSel}
                    onChange={() => toggleSelect(n.id)}
                    className="mt-1.5 shrink-0 rounded cursor-pointer accent-primary"
                  />

                  <div
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center shrink-0 text-white  mt-0.5"
                    style={{ backgroundColor: sev }}
                  >
                    {severityIcon(n.severity)}
                  </div>

                  <div
                    className="flex-1 min-w-0 cursor-pointer"
                    onClick={() => onOpen(n)}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-2">
                      <h2
                        className="text-xs sm:text-sm tracking-tight transition-colors group-hover:underline"
                        style={{ fontWeight: n.read ? 500 : 700 }}
                      >
                        {n.title}
                      </h2>
                      <span className="text-[10px] sm:text-[11px] opacity-50 shrink-0 font-medium">
                        {relativeTime(n.createdAt)}
                      </span>
                    </div>

                    {n.body && (
                      <p className="text-xs opacity-70 mt-1 line-clamp-2 leading-relaxed">
                        {n.body}
                      </p>
                    )}

                    <div className="flex items-center gap-2.5 mt-2.5 flex-wrap">
                      <span
                        className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                        style={{
                          backgroundColor:
                            theme === "dark"
                              ? "rgba(255,255,255,0.08)"
                              : "rgba(0,0,0,0.05)",
                          color: colors.text,
                        }}
                      >
                        {n.module.replace("_", " ")}
                      </span>

                      {!n.read && (
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: primaryColor }}
                        />
                      )}

                      {href && (
                        <span className="inline-flex items-center gap-0.5 text-[11px] font-semibold opacity-60 ml-auto group-hover:opacity-100 transition-opacity">
                          <T>View details</T> <ChevronRight size={12} />
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {hasMore && (
          <div
            className="p-4 border-t flex justify-center"
            style={{ borderColor: border }}
          >
            <button
              type="button"
              disabled={loadingMore}
              onClick={() => dispatch(fetchMoreNotifications())}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold border disabled:opacity-50 transition-all hover:opacity-80"
              style={{
                borderColor: border,
                backgroundColor: colors.shadeBgSecond,
              }}
            >
              {loadingMore ? (
                <Loader2 size={14} className="animate-spin" />
              ) : null}
              <T>Load older notifications</T>
            </button>
          </div>
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between text-xs opacity-60 px-2 gap-2 text-center sm:text-left">
        <p>
          <T>
            Notifications are scoped to your active facilities. Critical
            clinical alerts surface first.
          </T>
        </p>
        <Link
          href="/dashboard/settings"
          className="underline font-medium hover:opacity-100 transition-opacity shrink-0"
        >
          <T>Notification preferences</T>
        </Link>
      </div>
    </div>
  );
}
