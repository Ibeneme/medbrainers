import MedBrainersMosaic from "@/components/landing-page/home/Medbrainersmosaic";
import IntegrationsShowcase, {
  features,
} from "@/components/landing-page/home/after-hero";
import EnterpriseSupportSection from "@/components/landing-page/home/features-section";
import Hero from "@/components/landing-page/home/hero";
import MedBrainersIntro from "@/components/landing-page/home/intro";
import Testimonials from "@/components/landing-page/home/testimonials";
import { pageMetadata, type LangParams } from "@/i18n/seo";
import { SITE } from "@/constants/site";
import DataSecurity from "@/components/landing-page/home/data-security";
import Countdown from "@/components/atoms/timers/countdown";

export async function generateMetadata({ params }: LangParams) {
  return pageMetadata(
    params,
    "/",
    `${SITE.name} | EMR & Hospital Management Software`,
    SITE.description,
    {
      absoluteTitle: true,
    }
  );
}

export default function Home() {
  return (
    <div>
      <Hero />
      <IntegrationsShowcase />
      <MedBrainersIntro />
      <EnterpriseSupportSection />
      <Testimonials />
      <DataSecurity />
      <MedBrainersMosaic /> 
      <Countdown />
    </div>
  );
}
