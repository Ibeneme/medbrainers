import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api, { getErrorMessage, type ApiSuccess } from "../services";

export interface LabCatalogItem {
  _id: string;
  code?: string;
  name: string;
  category?: string;
  specimenType?: string;
  turnaroundHours?: number;
  price?: number;
  active?: boolean;
  createdAt?: string;
}

export interface LabRequest {
  _id: string;
  patientId: string | { _id: string; firstName?: string; lastName?: string; mrn?: string };
  requestedBy?: string | { _id: string; firstName?: string; lastName?: string };
  tests?: Array<{
    catalogId?: string;
    name: string;
    code?: string;
    status?: string;
    result?: string | number;
    unit?: string;
    referenceRange?: string;
    verified?: boolean;
    verifiedBy?: string;
    verifiedAt?: string;
  }>;
  priority?: "routine" | "urgent" | "stat";
  status?: "pending" | "collected" | "processing" | "completed" | "cancelled";
  clinicalNotes?: string;
  collectedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Specimen {
  _id: string;
  requestId?: string;
  patientId?: string | { _id: string; firstName?: string; lastName?: string; mrn?: string };
  type?: string;
  barcode?: string;
  status?: "collected" | "in_transit" | "received" | "rejected" | "processed";
  collectedAt?: string;
  receivedAt?: string;
  notes?: string;
}

export interface LabsState {
  catalog: LabCatalogItem[];
  requests: LabRequest[];
  specimens: Specimen[];
  listLoading: boolean;
  saving: boolean;
  error: string | null;
  message: string | null;
}

const initialState: LabsState = {
  catalog: [],
  requests: [],
  specimens: [],
  listLoading: false,
  saving: false,
  error: null,
  message: null,
};

export const fetchLabCatalog = createAsyncThunk(
  "labs/fetchCatalog",
  async (
    { facilityId, search }: { facilityId: string; search?: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<LabCatalogItem[]>>(
        `/companies/${facilityId}/labs/catalog`,
        { params: { search } },
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load lab catalog"));
    }
  },
);

export const addLabCatalogItem = createAsyncThunk(
  "labs/addCatalogItem",
  async (
    {
      facilityId,
      payload,
    }: {
      facilityId: string;
      payload: {
        name: string;
        code?: string;
        category?: string;
        specimenType?: string;
        turnaroundHours?: number;
        price?: number;
      };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<LabCatalogItem>>(
        `/companies/${facilityId}/labs/catalog`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not add catalog item"));
    }
  },
);

export const fetchLabRequests = createAsyncThunk(
  "labs/fetchRequests",
  async (
    {
      facilityId,
      patientId,
      status,
    }: { facilityId: string; patientId?: string; status?: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<LabRequest[]>>(
        `/companies/${facilityId}/labs/requests`,
        { params: { patientId, status } },
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load lab requests"));
    }
  },
);

export const createLabRequest = createAsyncThunk(
  "labs/createRequest",
  async (
    {
      facilityId,
      payload,
    }: {
      facilityId: string;
      payload: {
        patientId: string;
        tests: Array<{ catalogId?: string; name: string; code?: string }>;
        priority?: string;
        clinicalNotes?: string;
      };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<LabRequest>>(
        `/companies/${facilityId}/labs/requests`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not create lab request"));
    }
  },
);

export const collectSpecimen = createAsyncThunk(
  "labs/collectSpecimen",
  async (
    {
      facilityId,
      id,
      payload,
    }: {
      facilityId: string;
      id: string;
      payload?: { barcode?: string; notes?: string };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<LabRequest>>(
        `/companies/${facilityId}/labs/requests/${id}/collect`,
        payload || {},
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not collect specimen"));
    }
  },
);

export const enterLabResult = createAsyncThunk(
  "labs/enterResult",
  async (
    {
      facilityId,
      id,
      testIndex,
      payload,
    }: {
      facilityId: string;
      id: string;
      testIndex: number;
      payload: { result: string | number; unit?: string; referenceRange?: string };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<LabRequest>>(
        `/companies/${facilityId}/labs/requests/${id}/results/${testIndex}`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not enter result"));
    }
  },
);

export const verifyLabResult = createAsyncThunk(
  "labs/verifyResult",
  async (
    {
      facilityId,
      id,
      testIndex,
    }: { facilityId: string; id: string; testIndex: number },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<LabRequest>>(
        `/companies/${facilityId}/labs/requests/${id}/verify/${testIndex}`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not verify result"));
    }
  },
);

export const fetchSpecimens = createAsyncThunk(
  "labs/fetchSpecimens",
  async (
    { facilityId, status }: { facilityId: string; status?: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<Specimen[]>>(
        `/companies/${facilityId}/labs/specimens`,
        { params: { status } },
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load specimens"));
    }
  },
);

const labsSlice = createSlice({
  name: "labs",
  initialState,
  reducers: {
    clearLabsError(s) {
      s.error = null;
      s.message = null;
    },
  },
  extraReducers: (b) => {
    const fail = (s: LabsState, a: { payload?: unknown }) => {
      s.listLoading = false;
      s.saving = false;
      s.error = (a.payload as string) || "Request failed";
    };

    b.addCase(fetchLabCatalog.pending, (s) => {
      s.listLoading = true;
      s.error = null;
    })
      .addCase(fetchLabCatalog.fulfilled, (s, a) => {
        s.listLoading = false;
        s.catalog = a.payload.data || [];
      })
      .addCase(fetchLabCatalog.rejected, fail);

    b.addCase(addLabCatalogItem.pending, (s) => {
      s.saving = true;
    })
      .addCase(addLabCatalogItem.fulfilled, (s, a) => {
        s.saving = false;
        s.message = a.payload.message || "Catalog item added";
        if (a.payload.data) s.catalog = [a.payload.data, ...s.catalog];
      })
      .addCase(addLabCatalogItem.rejected, fail);

    b.addCase(fetchLabRequests.pending, (s) => {
      s.listLoading = true;
      s.error = null;
    })
      .addCase(fetchLabRequests.fulfilled, (s, a) => {
        s.listLoading = false;
        s.requests = a.payload.data || [];
      })
      .addCase(fetchLabRequests.rejected, fail);

    b.addCase(createLabRequest.pending, (s) => {
      s.saving = true;
    })
      .addCase(createLabRequest.fulfilled, (s, a) => {
        s.saving = false;
        s.message = a.payload.message || "Lab request created";
        if (a.payload.data) s.requests = [a.payload.data, ...s.requests];
      })
      .addCase(createLabRequest.rejected, fail);

    b.addCase(collectSpecimen.fulfilled, (s, a) => {
      s.saving = false;
      s.message = "Specimen collected";
      if (a.payload.data) {
        const idx = s.requests.findIndex((r) => r._id === a.payload.data!._id);
        if (idx >= 0) s.requests[idx] = a.payload.data;
      }
    });

    b.addCase(enterLabResult.fulfilled, (s, a) => {
      s.saving = false;
      s.message = "Result entered";
      if (a.payload.data) {
        const idx = s.requests.findIndex((r) => r._id === a.payload.data!._id);
        if (idx >= 0) s.requests[idx] = a.payload.data;
      }
    });

    b.addCase(verifyLabResult.fulfilled, (s, a) => {
      s.saving = false;
      s.message = "Result verified";
      if (a.payload.data) {
        const idx = s.requests.findIndex((r) => r._id === a.payload.data!._id);
        if (idx >= 0) s.requests[idx] = a.payload.data;
      }
    });

    b.addCase(fetchSpecimens.pending, (s) => {
      s.listLoading = true;
    })
      .addCase(fetchSpecimens.fulfilled, (s, a) => {
        s.listLoading = false;
        s.specimens = a.payload.data || [];
      })
      .addCase(fetchSpecimens.rejected, fail);
  },
});

export const { clearLabsError } = labsSlice.actions;
export default labsSlice.reducer;
