import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api, { getErrorMessage, type ApiSuccess } from "../services";
import type {
  FamilyGroup,
  Patient,
  PatientFamilyResponse,
  RegisterPatientPayload,
} from "../types";

export interface ActivityLog {
  _id: string;
  at: string;
  by: {
    _id: string;
    firstName?: string;
    lastName?: string;
    email?: string;
  } | string;
  action: string;
  details?: string;
}

export interface PatientsState {
  list: Patient[];
  current: (Patient & { activityLogs?: ActivityLog[] }) | null;
  familyView: PatientFamilyResponse | null;
  families: FamilyGroup[];
  alerts: unknown[];
  listLoading: boolean;
  detailLoading: boolean;
  saving: boolean;
  error: string | null;
  message: string | null;
  meta: { page: number; limit: number; total: number } | null;
}

const initialState: PatientsState = {
  list: [],
  current: null,
  familyView: null,
  families: [],
  alerts: [],
  listLoading: false,
  detailLoading: false,
  saving: false,
  error: null,
  message: null,
  meta: null,
};

export const fetchPatients = createAsyncThunk(
  "patients/fetchList",
  async (
    {
      facilityId,
      search,
      status,
      page,
    }: { facilityId: string; search?: string; status?: string; page?: number },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<Patient[]> & { role?: string; meta?: PatientsState["meta"] }>(
        `/companies/${facilityId}/patients`,
        { params: { search, status, page } },
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load patients"));
    }
  },
);

export const fetchPatient = createAsyncThunk(
  "patients/fetchOne",
  async (
    { facilityId, patientId }: { facilityId: string; patientId: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<Patient> & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load patient"));
    }
  },
);

export const registerPatient = createAsyncThunk(
  "patients/register",
  async (
    { facilityId, payload }: { facilityId: string; payload: RegisterPatientPayload },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<Patient> & { role?: string }>(
        `/companies/${facilityId}/patients`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Registration failed"));
    }
  },
);

export const addPatientHistory = createAsyncThunk(
  "patients/addHistory",
  async (
    {
      facilityId,
      patientId,
      payload,
    }: {
      facilityId: string;
      patientId: string;
      payload: { type?: string; title: string; detail?: string; icdCode?: string };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/history`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not add chart entry"));
    }
  },
);

export const addPatientAllergy = createAsyncThunk(
  "patients/addAllergy",
  async (
    {
      facilityId,
      patientId,
      payload,
    }: {
      facilityId: string;
      patientId: string;
      payload: { substance: string; reaction?: string; severity?: string; notes?: string };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/allergies`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not add allergy"));
    }
  },
);

export const updatePatientAllergy = createAsyncThunk(
  "patients/updateAllergy",
  async (
    {
      facilityId,
      patientId,
      allergyId,
      payload,
    }: {
      facilityId: string;
      patientId: string;
      allergyId: string;
      payload: { substance?: string; reaction?: string; severity?: string; notes?: string };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.patch<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/allergies/${allergyId}`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not update allergy"));
    }
  },
);

export const removePatientAllergy = createAsyncThunk(
  "patients/removeAllergy",
  async (
    {
      facilityId,
      patientId,
      allergyId,
    }: { facilityId: string; patientId: string; allergyId: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.delete<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/allergies/${allergyId}`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not remove allergy"));
    }
  },
);

export const addPatientVital = createAsyncThunk(
  "patients/addVital",
  async (
    {
      facilityId,
      patientId,
      payload,
    }: { facilityId: string; patientId: string; payload: Record<string, number | string> },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/vitals`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not record vitals"));
    }
  },
);

export const updatePatientVital = createAsyncThunk(
  "patients/updateVital",
  async (
    {
      facilityId,
      patientId,
      vitalId,
      payload,
    }: {
      facilityId: string;
      patientId: string;
      vitalId: string;
      payload: Record<string, number | string>;
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.patch<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/vitals/${vitalId}`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not update vital"));
    }
  },
);

export const removePatientVital = createAsyncThunk(
  "patients/removeVital",
  async (
    {
      facilityId,
      patientId,
      vitalId,
    }: { facilityId: string; patientId: string; vitalId: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.delete<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/vitals/${vitalId}`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not remove vital"));
    }
  },
);

export const addPatientFamily = createAsyncThunk(
  "patients/addFamily",
  async (
    {
      facilityId,
      patientId,
      payload,
    }: {
      facilityId: string;
      patientId: string;
      payload: {
        name: string;
        relationship: string;
        phone?: string;
        countryCode?: string;
        isEmergencyContact?: boolean;
        patientRef?: string;
      };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/family`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not add family member"));
    }
  },
);

export const fetchVitalAlerts = createAsyncThunk(
  "patients/fetchAlerts",
  async (facilityId: string, { rejectWithValue }) => {
    try {
      const { data } = await api.get<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/alerts/vitals`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load alerts"));
    }
  },
);

export const fetchPatientFamily = createAsyncThunk(
  "patients/fetchFamily",
  async (
    { facilityId, patientId }: { facilityId: string; patientId: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<PatientFamilyResponse> & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/family`,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load family"));
    }
  },
);

export const linkPatientsAsFamily = createAsyncThunk(
  "patients/linkFamily",
  async (
    {
      facilityId,
      payload,
    }: {
      facilityId: string;
      payload: {
        patientIds: string[];
        name?: string;
        headPatientId?: string;
        notes?: string;
      };
    },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.post<ApiSuccess<FamilyGroup> & { role?: string }>(
        `/companies/${facilityId}/patients/families/link`,
        payload,
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not link family"));
    }
  },
);

/** Alias used by patient detail page */
export const linkFamily = linkPatientsAsFamily;

export const fetchFamilies = createAsyncThunk(
  "patients/fetchFamilies",
  async (
    { facilityId, search }: { facilityId: string; search?: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.get<ApiSuccess<FamilyGroup[]> & { role?: string }>(
        `/companies/${facilityId}/patients/families`,
        { params: { search } },
      );
      return data;
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Failed to load families"));
    }
  },
);

export const removeFromFamilyGroup = createAsyncThunk(
  "patients/removeFromFamily",
  async (
    { facilityId, patientId }: { facilityId: string; patientId: string },
    { rejectWithValue },
  ) => {
    try {
      const { data } = await api.delete<ApiSuccess & { role?: string }>(
        `/companies/${facilityId}/patients/${patientId}/family-group`,
      );
      return { ...data, patientId };
    } catch (err) {
      return rejectWithValue(getErrorMessage(err, "Could not remove from family"));
    }
  },
);

const patientsSlice = createSlice({
  name: "patients",
  initialState,
  reducers: {
    clearPatientsError(s) {
      s.error = null;
      s.message = null;
    },
    clearCurrentPatient(s) {
      s.current = null;
    },
  },
  extraReducers: (b) => {
    const fail = (s: PatientsState, a: { payload?: unknown }) => {
      s.listLoading = false;
      s.detailLoading = false;
      s.saving = false;
      s.error = (a.payload as string) || "Request failed";
    };

    // Helper to update state.auth.user.role if the response contains a role
    const updateAuthRole = (state: any, action: any) => {
      const newRole = action.payload?.role;
      if (newRole && state?.auth?.user) {
        state.auth.user.role = newRole;
      }
    };

    b.addCase(fetchPatients.pending, (s) => {
      s.listLoading = true;
      s.error = null;
    })
      .addCase(fetchPatients.fulfilled, (s, a) => {
        s.listLoading = false;
        s.list = a.payload.data || [];
        s.meta = (a.payload as any).meta || null;
        updateAuthRole(s, a);
      })
      .addCase(fetchPatients.rejected, fail);

    b.addCase(fetchPatient.pending, (s) => {
      s.detailLoading = true;
    })
      .addCase(fetchPatient.fulfilled, (s, a) => {
        s.detailLoading = false;
        s.current = a.payload.data || null;
        updateAuthRole(s, a);
      })
      .addCase(fetchPatient.rejected, fail);

    b.addCase(registerPatient.pending, (s) => {
      s.saving = true;
    })
      .addCase(registerPatient.fulfilled, (s, a) => {
        s.saving = false;
        s.message = a.payload.message || "Patient registered";
        if (a.payload.data) s.list = [a.payload.data, ...s.list];
        updateAuthRole(s, a);
      })
      .addCase(registerPatient.rejected, fail);

    b.addCase(addPatientHistory.fulfilled, (s, a) => {
      s.saving = false;
      s.message = "Chart entry added";
      updateAuthRole(s, a);
    })
      .addCase(addPatientAllergy.fulfilled, (s, a) => {
        s.saving = false;
        s.message = "Allergy recorded";
        updateAuthRole(s, a);
      })
      .addCase(updatePatientAllergy.fulfilled, (s, a) => {
        s.saving = false;
        s.message = "Allergy updated";
        updateAuthRole(s, a);
      })
      .addCase(removePatientAllergy.fulfilled, (s, a) => {
        s.saving = false;
        s.message = "Allergy removed";
        updateAuthRole(s, a);
      })
      .addCase(addPatientVital.fulfilled, (s, a) => {
        s.saving = false;
        s.message = (a.payload as any).message || "Vital recorded";
        updateAuthRole(s, a);
      })
      .addCase(updatePatientVital.fulfilled, (s, a) => {
        s.saving = false;
        s.message = (a.payload as any).message || "Vital updated";
        updateAuthRole(s, a);
      })
      .addCase(removePatientVital.fulfilled, (s, a) => {
        s.saving = false;
        s.message = (a.payload as any).message || "Vital removed";
        updateAuthRole(s, a);
      })
      .addCase(addPatientFamily.fulfilled, (s, a) => {
        s.saving = false;
        s.message = "Family member added";
        updateAuthRole(s, a);
      });

    b.addCase(fetchVitalAlerts.fulfilled, (s, a) => {
      s.alerts = (a.payload as any).data || [];
      updateAuthRole(s, a);
    });

    b.addCase(fetchPatientFamily.fulfilled, (s, a) => {
      s.familyView = a.payload.data || null;
      updateAuthRole(s, a);
    });

    b.addCase(linkPatientsAsFamily.fulfilled, (s, a) => {
      s.saving = false;
      s.message = a.payload.message || "Family linked";
      if (a.payload.data) {
        const g = a.payload.data;
        const idx = s.families.findIndex((f) => f._id === g._id);
        if (idx >= 0) s.families[idx] = g;
        else s.families = [g, ...s.families];
      }
      updateAuthRole(s, a);
    });

    b.addCase(fetchFamilies.fulfilled, (s, a) => {
      s.families = a.payload.data || [];
      updateAuthRole(s, a);
    });
  },
});

export const { clearPatientsError, clearCurrentPatient } = patientsSlice.actions;
export default patientsSlice.reducer;